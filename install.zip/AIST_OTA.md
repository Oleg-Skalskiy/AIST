### AIST v1.9 - 25.09.2023

* Sound changes
		* Fix Fixing 48 or 96 kHz / Float or 24 bit
		* Updated Bluetooth Parametrs
		* Updated Dolby Parametrs
		* Improved Stability
		* Fix Surround Effect
		* Fix Media Codec
		* Add New Sound Parameters
		* Fix Microphone
		* Fix Direct Output
		* New option for Xiaomi and BBK
		* Echo Reference OFF
		* Multi-Voice Channel fix
		* Fix Lags
		* Minor edits
* In item Other
		* Improved system smoothness
		* New Camera Parametrs
		* New Systems Parametrs
		* Removed waste parameters
		* Updated Radio(Modem) Parametrs
		* Fixed excessive battery consumption
		* Added new options for MIUI
		* FIX OFF Logging
		* Minor edits
		* Fix SSR (25.09)
* General
		* Fix Code
		* Fix Some Error
		* Fix Stability System
		* Minor edits
		* Updated base module file MMT (Thanks Zackptg5)
