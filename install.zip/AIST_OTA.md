### AIST v1.6 - 01.09.2022

* Sound changes
  * Fix Fixing 96 or 192 kHz
  * Fix Bluetooth Audio Frame
  * Fix TWS+
  * Improved Stability
  * Fix Direct output
  * Fix Offload
  * Fix 24 bit mode
  * Fix Surround Effect
  * Fix Camera Error
  * New option for Xiaomi and Realme
  * Oxygen 12 Support (TEST)
  * Minor edits
* In item Other
  * Improved system smoothness
  * New Camera Parametrs
  * New Systems Parametrs
  * Add New Video Mode
  * Add New Radio Mode
  * Removed waste parameters
  * Fixed System Error
  * Fixed excessive battery consumption
  * Fixed statistics
  * Fix FPS
  * Added new options for MIUI
  * FIX OFF Logging
  * Minor edits
* General
  * Add remove dalvik-cache, cache, logs & traces after installation
  * Minor edits

  