### AIST v1.5 - 09.05.2022

* Sound changes
  * Del Custom IIR
  * Fix APTX Adaptive
  * Fix Bluetooth Offload
  * Fix TWS+
  * ADD item FIXING 96kHz out
  * Bypass Compress Offload
  * Dolby Vision Off (audio) (Off default)
  * Edit Dolby Config
  * New Bluetooth Parametrs
  * Low Power Audio OFF
  * Fix USB Offload
  * Reduced power consumption.
  * Fix 24 bit error
  * Minor edits
* In item Other
  * Improved system smoothness
  * New Camera Parametrs
  * New Systems Parametrs 
  * Removed waste parameters
  * Fixed System Error
  * Fixed excessive battery consumption
  * Fixed statistics
  * Fix MIUI tweaks
  * Fixed FPS work
  * Removed conflicting display options
  * Fixed LMK work
  * Added new options for MIUI
  * FIX OFF ATracing 
  * Minor edits 
