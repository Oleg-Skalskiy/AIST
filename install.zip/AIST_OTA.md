### AIST v1.7 - 01.01.2023

* Sound changes
  * Fix Fixing 96 or 192 kHz
  * Fix Bluetooth Error
  * Fix Dolby Error
  * Improved Stability
  * Fix Surround Effect
  * Fix Camera Error
  * BPF LPF HPF is OFF
  * Fix Camera Error
  * Fix Camera Error
  * New option for Xiaomi and Realme
  * Oxygen 12 Support
  * Minor edits
* In item Other
  * Improved system smoothness
  * New Camera Parametrs
  * New Systems Parametrs
  * Fix Display Mode (Paper Mode)
  * Removed waste parameters
  * Fixed System Error
  * Fixed excessive battery consumption
  * Added new options for MIUI
  * FIX OFF Logging
  * FIX Radio Parametrs (Modem)
* General
  * Fix Code
  * Minor edits
