### AIST v2.0 - 01.07.2024

* Sound changes
  * Fix Fixing 48 or 96 kHz / Float or 24 bit
  * Updated Bluetooth Parametrs
  * Fix Excessive Bluetooth Consumption
  * Fix BLE & LE Audio
  * Updated Dolby Parametrs
  * Echo Noise Suppressor is Disabled
  * Fix Microphone Sensitivity
  * Fix Media Codec
  * Add New Sound Parameters
  * Fix Microphone
  * Fix Direct Output
  * New option for Xiaomi and BBK
  * Echo Reference OFF
  * Multi-Voice Channel fix
  * Fix Lags
  * Minor edits
* General
  * Fix Code
  * Fix Some Error
  * Fix Stability System
  * Minor edits
  * Updated base module file MMT (Thanks Zackptg5)
