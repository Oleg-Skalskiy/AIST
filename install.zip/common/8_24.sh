# Service controller script

resetprop -p --delete persist.audio_hal.dsp_bit_width_enforce_mode
resetprop -p --delete persist.vendor.audio_hal.dsp_bit_width_enforce_mode
resetprop -p --delete media.resolution.limit.16bit
resetprop -p --delete media.resolution.limit.24bit
resetprop -p --delete media.resolution.limit.32bit
resetprop -p --delete media.resolution.limit.64bit
