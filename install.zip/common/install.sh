
umount -f /odm/etc/audio/
umount -f /odm/etc/audio_policy_configuration.xml
umount -f /odm/etc/audio_io_policy.conf
umount -f /odm/etc/audio_platform_info.xml
umount -f /odm/etc/audio_configs.xml
umount -f /odm/etc/a2dp_audio_policy_configuration.xml
umount -f /odm/etc/a2dp_in_audio_policy_configuration.xml
umount -f /odm/etc/bluetooth_qti_audio_policy_configuration.xml
umount -f /odm/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml
umount -f /odm/etc/hearing_aid_audio_policy_configuration.xml
umount -f /odm/etc/r_submix_audio_policy_configuration.xml
umount -f /odm/etc/usb_audio_policy_configuration.xml
umount -f /odm/etc/vehicle_display_audio_policy_configuration.xml
umount -f /odm/etc/virtual_audio_policy_configuration.xml
umount -f /odm/etc/media_codecs_google_audio.xml
umount -f /odm/etc/media_codecs_google_c2_audio.xml
umount -f /odm/etc/media_codecs_vendor_audio.xml
umount -f /odm/etc/media_codecs_dolby_audio.xml
umount -f /odm/etc/mixer_paths.xml
umount -f /odm/etc/ftm_mixer_paths.xml
umount -f /odm/etc/sound_trigger_mixer_paths.xml
umount -f /odm/etc/resourcemanager.xml
umount -f /odm/etc/sound_trigger_platform_info.xml
umount -f /odm/etc/sound_trigger_platform_info.xml/
umount -f /odm/etc/dolby/

umount -f /my_product/etc/audio/
umount -f /my_product/etc/audio_policy_configuration.xml
umount -f /my_product/etc/audio_io_policy.conf
umount -f /my_product/etc/audio_platform_info.xml
umount -f /my_product/etc/audio_configs.xml
umount -f /my_product/etc/a2dp_audio_policy_configuration.xml
umount -f /my_product/etc/a2dp_in_audio_policy_configuration.xml
umount -f /my_product/etc/bluetooth_qti_audio_policy_configuration.xml
umount -f /my_product/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml
umount -f /my_product/etc/hearing_aid_audio_policy_configuration.xml
umount -f /my_product/etc/r_submix_audio_policy_configuration.xml
umount -f /my_product/etc/usb_audio_policy_configuration.xml
umount -f /my_product/etc/vehicle_display_audio_policy_configuration.xml
umount -f /my_product/etc/virtual_audio_policy_configuration.xml
umount -f /my_product/etc/media_codecs_google_audio.xml
umount -f /my_product/etc/media_codecs_google_c2_audio.xml
umount -f /my_product/etc/media_codecs_vendor_audio.xml
umount -f /my_product/etc/media_codecs_dolby_audio.xml
umount -f /my_product/etc/mixer_paths.xml
umount -f /my_product/etc/ftm_mixer_paths.xml
umount -f /my_product/etc/sound_trigger_mixer_paths.xml
umount -f /my_product/etc/resourcemanager.xml
umount -f /my_product/etc/sound_trigger_platform_info.xml
umount -f /my_product/etc/sound_trigger_platform_info.xml/
umount -f /my_product/etc/dolby/

AIST_proc() {
  local Name0=$(echo "$3" | sed -r "s|^.*/.*\[@(.*)=\".*\".*$|\1|")
  local Value0=$(echo "$3" | sed -r "s|^.*/.*\[@.*=\"(.*)\".*$|\1|")
  [ "$(echo "$4" | grep '=')" ] && Name1=$(echo "$4" | sed "s|=.*||") || local Name1="value"
  local Value1=$(echo "$4" | sed "s|.*=||")
  case $1 in
  "-s"|"-u"|"-i")
    local SNP=$(echo "$3" | sed -r "s|(^.*/.*)\[@.*=\".*\".*$|\1|")
    local NP=$(dirname "$SNP")
    local SN=$(basename "$SNP")
	if [ "$5" ]; then
      [ "$(echo "$5" | grep '=')" ] && local Name2=$(echo "$5" | sed "s|=.*||") || local Name2="value"
      local Value2=$(echo "$5" | sed "s|.*=||")
	fi
	if [ "$6" ]; then
      [ "$(echo "$6" | grep '=')" ] && local Name3=$(echo "$6" | sed "s|=.*||") || local Name3="value"
      local Value3=$(echo "$6" | sed "s|.*=||")
	fi
	if [ "$7" ]; then
      [ "$(echo "$7" | grep '=')" ] && local Name4=$(echo "$7" | sed "s|=.*||") || local Name4="value"
      local Value4=$(echo "$7" | sed "s|.*=||")
	fi
  ;;
  esac
  case "$1" in
    "-d") xmlstarlet ed -L -d "$3" "$2";;
    "-u") xmlstarlet ed -L -u "$3/@$Name1" -v "$Value1" "$2";;
    "-s")
  	if [ "$(xmlstarlet sel -t -m "$3" -c . "$2")" ]; then
        xmlstarlet ed -L -u "$3/@$Name1" -v "$Value1" "$2"
      else
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -r "$SNP-$MODID" -v "$SN" "$2"
  	fi;;
    "-i")
  	if [ "$(xmlstarlet sel -t -m "$3[@$Name1=\"$Value1\"]" -c . "$2")" ]; then
        xmlstarlet ed -L -d "$3[@$Name1=\"$Value1\"]" "$2"
  	fi
  	if [ -z "$Value3" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -r "$SNP-$MODID" -v "$SN" "$2"
      elif [ "$Value4" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -i "$SNP-$MODID" -t attr -n "$Name3" -v "$Value3" \
        -i "$SNP-$MODID" -t attr -n "$Name4" -v "$Value4" \
        -r "$SNP-$MODID" -v "$SN" "$2"
      elif [ "$Value3" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -i "$SNP-$MODID" -t attr -n "$Name3" -v "$Value3" \
        -r "$SNP-$MODID" -v "$SN" "$2"
  	fi
      ;;
  esac
}

[ -f /system/vendor/build.prop ] && BUILDS="/system/build.prop /system/vendor/build.prop" || BUILDS="/system/build.prop"
SD617=$(grep "ro.board.platform=msm8952" $BUILDS)
SD625=$(grep "ro.board.platform=msm8953" $BUILDS)
SD660=$(grep "ro.board.platform=sdm660" $BUILDS)
SD662=$(grep "ro.board.platform=bengal" $BUILDS)
SD665=$(grep "ro.board.platform=trinket" $BUILDS)
SD670=$(grep "ro.board.platform=sdm670" $BUILDS)
SD710=$(grep "ro.board.platform=sdm710" $BUILDS)
SD720G=$(grep "ro.board.platform=atoll" $BUILDS)
SD730G=$(grep "ro.board.platform=sm6150" $BUILDS)
SD765G=$(grep "ro.board.platform=lito" $BUILDS)
SD820=$(grep "ro.board.platform=msm8996" $BUILDS)
SD835=$(grep "ro.board.platform=msm8998" $BUILDS)
SD845=$(grep "ro.board.platform=sdm845" $BUILDS)
SD855=$(grep "ro.board.platform=msmnile" $BUILDS)
SD865=$(grep "ro.board.platform=kona" $BUILDS)
SD888=$(grep "ro.board.platform=lahaina" $BUILDS)
SM6375=$(grep "ro.board.platform=holi" $BUILDS)
SM8450=$(grep "ro.board.platform=taro" $BUILDS)
SM8550=$(grep "ro.board.platform=kalama" $BUILDS)

if [ "$SD662" ] || [ "$SD665" ] || [ "$SD670" ] || [ "$SD710" ] || [ "$SD720G" ] || [ "$SD730G" ] || [ "$SD765G" ] || [ "$SD820" ] || [ "$SD835" ] || [ "$SD845" ] || [ "$SD855" ] || [ "$SD865" ] || [ "$SD888" ] || [ "$SM6375" ] || [ "$SM8450" ] || [ "$SM8550" ]; then
  HIFI=true
ui_print " "
ui_print "***************************************************"
ui_print "***************************************************"
ui_print "*   ->[Device with support Hi-Res detected!]<-    *"
else
  NOHIFI=false
ui_print " "
ui_print "***************************************************"
ui_print "***************************************************"
ui_print "*  ->[Device without support Hi-Res detected!]<-  *"
fi

ui_print "*          ->[Preparing! Please Wait!]<-          *"
ui_print "***************************************************"
ui_print "***************************************************"

RN5PRO=$(grep -E "ro.product.vendor.device=whyred.*" $BUILDS)
RN6PRO=$(grep -E "ro.product.vendor.device=tulip.*" $BUILDS)
RN7=$(grep -E "ro.product.vendor.device=lavender.*" $BUILDS)
RN7PRO=$(grep -E "ro.product.vendor.device=violet.*" $BUILDS)
MI9=$(grep -E "ro.product.vendor.device=cepheus.*" $BUILDS)
MI10=$(grep -E "ro.product.vendor.device=umi.*" $BUILDS)
K20P=$(grep -E "ro.product.vendor.device=raphael.*|ro.product.vendor.device=raphaelin.*|ro.product.vendor.device=raphaels.*" $BUILDS)
MI8=$(grep -E "ro.product.vendor.device=dipper.*" $BUILDS)
MI8P=$(grep -E "ro.product.vendor.device=equuleus.*" $BUILDS)
MI9P=$(grep -E "ro.product.vendor.device=crux.*" $BUILDS)
POCOF1=$(grep -E "ro.product.vendor.device=beryllium.*" $BUILDS)
POCOF2P=$(grep -E "ro.product.vendor.device=lmi.*" $BUILDS)

QCVIRTJ="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "qvirtmgr.json")"
MPATHS="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "*mixer_path*.xml")"
APINF="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "audio_platform_info*.xml")"
ACONFS="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "audio_configs*.xml")"
ACCXML="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "audio_cloud_control*.xml")"
APCXML="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "audio_policy_configuration*.xml")"
A2DPXML="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "a2dp*.xml")"
VEHXML="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "vehicle*.xml")"
VIRTXML="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "virtual*.xml")"
USBXML="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "usb*.xml")"
BTQTIXML="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "bluetooth*.xml")"
APIOCXML="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "audio_output_policy.conf")$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "audio_io_policy.conf")"
DEVF="$(find /system/etc/device_features /vendor/etc/device_features /system_ext/etc/device_features /product/etc/device_features /odm/etc/device_features /my_product/etc/device_features /mi_ext/etc/device_features -type f -name "*.xml")"
DAXXML="$(find /system/etc/dolby /vendor/etc/dolby /system_ext/etc/dolby /product/etc/dolby /odm/etc/dolby /my_product/etc/dolby /mi_ext/etc/dolby -type f -name "*.xml")"
BTCONF="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "bt_configstore*.conf")"
BTCONF2="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "bt_stack*.conf")"
MEDCA="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "media_codecs*audio.xml")"
ATRACE="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "atrace.rc")"
SNDTRPL="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "sound_trigger_platform_info*.xml")$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "resourcemanager*.xml")"
LOG=$MODPATH/common/other

mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/


cp_ch -r /odm/etc/audio/ $MODPATH/system/vendor/odm/etc/audio/
cp_ch /odm/etc/audio_policy_configuration.xml $MODPATH/system/vendor/odm/etc/audio_policy_configuration.xml
cp_ch /odm/etc/audio_io_policy.conf $MODPATH/system/vendor/odm/etc/audio_io_policy.conf
cp_ch /odm/etc/audio_platform_info.xml $MODPATH/system/vendor/odm/etc/audio_platform_info.xml
cp_ch /odm/etc/audio_configs.xml $MODPATH/system/vendor/odm/etc/audio_configs.xml
cp_ch /odm/etc/a2dp_audio_policy_configuration.xml $MODPATH/system/vendor/odm/etc/a2dp_audio_policy_configuration.xml
cp_ch /odm/etc/a2dp_in_audio_policy_configuration.xml $MODPATH/system/vendor/odm/etc/a2dp_in_audio_policy_configuration.xml
cp_ch /odm/etc/bluetooth_qti_audio_policy_configuration.xml $MODPATH/system/vendor/odm/etc/bluetooth_qti_audio_policy_configuration.xml
cp_ch /odm/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml $MODPATH/system/vendor/odm/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml
cp_ch /odm/etc/hearing_aid_audio_policy_configuration.xml $MODPATH/system/vendor/odm/etc/hearing_aid_audio_policy_configuration.xml
cp_ch /odm/etc/r_submix_audio_policy_configuration.xml $MODPATH/system/vendor/odm/etc/r_submix_audio_policy_configuration.xml
cp_ch /odm/etc/usb_audio_policy_configuration.xml $MODPATH/system/vendor/odm/etc/usb_audio_policy_configuration.xml
cp_ch /odm/etc/vehicle_display_audio_policy_configuration.xml $MODPATH/system/vendor/odm/etc/vehicle_display_audio_policy_configuration.xml
cp_ch /odm/etc/virtual_audio_policy_configuration.xml $MODPATH/system/vendor/odm/etc/virtual_audio_policy_configuration.xml
cp_ch /odm/etc/media_codecs_google_audio.xml $MODPATH/system/vendor/odm/etc/media_codecs_google_audio.xml
cp_ch /odm/etc/media_codecs_google_c2_audio.xml $MODPATH/system/vendor/odm/etc/media_codecs_google_c2_audio.xml
cp_ch /odm/etc/media_codecs_vendor_audio.xml $MODPATH/system/vendor/odm/etc/media_codecs_vendor_audio.xml
cp_ch /odm/etc/media_codecs_dolby_audio.xml $MODPATH/system/vendor/odm/etc/media_codecs_dolby_audio.xml
cp_ch /odm/etc/mixer_paths.xml $MODPATH/system/vendor/odm/etc/mixer_paths.xml
cp_ch /odm/etc/ftm_mixer_paths.xml $MODPATH/system/vendor/odm/etc/ftm_mixer_paths.xml
cp_ch /odm/etc/sound_trigger_mixer_paths.xml $MODPATH/system/vendor/odm/etc/sound_trigger_mixer_paths.xml
cp_ch /odm/etc/sound_trigger_platform_info.xml $MODPATH/system/vendor/odm/etc/sound_trigger_platform_info.xml
cp_ch /odm/etc/resourcemanager.xml $MODPATH/system/vendor/odm/etc/resourcemanager.xml
cp_ch -r /odm/etc/sound_trigger_platform_info.xml/ $MODPATH/system/vendor/odm/etc/sound_trigger_platform_info.xml/
cp_ch -r /odm/etc/dolby/ $MODPATH/system/vendor/odm/etc/dolby/

cp_ch -r /my_product/etc/audio/ $MODPATH/system/my_product/etc/audio/
cp_ch /my_product/etc/audio_policy_configuration.xml $MODPATH/system/my_product/etc/audio_policy_configuration.xml
cp_ch /my_product/etc/audio_io_policy.conf $MODPATH/system/my_product/etc/audio_io_policy.conf
cp_ch /my_product/etc/audio_platform_info.xml $MODPATH/system/my_product/etc/audio_platform_info.xml
cp_ch /my_product/etc/audio_configs.xml $MODPATH/system/my_product/etc/audio_configs.xml
cp_ch /my_product/etc/a2dp_audio_policy_configuration.xml $MODPATH/system/my_product/etc/a2dp_audio_policy_configuration.xml
cp_ch /my_product/etc/a2dp_in_audio_policy_configuration.xml $MODPATH/system/my_product/etc/a2dp_in_audio_policy_configuration.xml
cp_ch /my_product/etc/bluetooth_qti_audio_policy_configuration.xml $MODPATH/system/my_product/etc/bluetooth_qti_audio_policy_configuration.xml
cp_ch /my_product/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml $MODPATH/system/my_product/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml
cp_ch /my_product/etc/hearing_aid_audio_policy_configuration.xml $MODPATH/system/my_product/etc/hearing_aid_audio_policy_configuration.xml
cp_ch /my_product/etc/r_submix_audio_policy_configuration.xml $MODPATH/system/my_product/etc/r_submix_audio_policy_configuration.xml
cp_ch /my_product/etc/usb_audio_policy_configuration.xml $MODPATH/system/my_product/etc/usb_audio_policy_configuration.xml
cp_ch /my_product/etc/vehicle_display_audio_policy_configuration.xml $MODPATH/system/my_product/etc/vehicle_display_audio_policy_configuration.xml
cp_ch /my_product/etc/virtual_audio_policy_configuration.xml $MODPATH/system/my_product/etc/virtual_audio_policy_configuration.xml
cp_ch /my_product/etc/media_codecs_google_audio.xml $MODPATH/system/my_product/etc/media_codecs_google_audio.xml
cp_ch /my_product/etc/media_codecs_google_c2_audio.xml $MODPATH/system/my_product/etc/media_codecs_google_c2_audio.xml
cp_ch /my_product/etc/media_codecs_vendor_audio.xml $MODPATH/system/my_product/etc/media_codecs_vendor_audio.xml
cp_ch /my_product/etc/media_codecs_dolby_audio.xml $MODPATH/system/my_product/etc/media_codecs_dolby_audio.xml
cp_ch /my_product/etc/mixer_paths.xml $MODPATH/system/my_product/etc/mixer_paths.xml
cp_ch /my_product/etc/ftm_mixer_paths.xml $MODPATH/system/my_product/etc/ftm_mixer_paths.xml
cp_ch /my_product/etc/sound_trigger_mixer_paths.xml $MODPATH/system/my_product/etc/sound_trigger_mixer_paths.xml
cp_ch /my_product/etc/sound_trigger_platform_info.xml $MODPATH/system/my_product/etc/sound_trigger_platform_info.xml
cp_ch /my_product/etc/resourcemanager.xml $MODPATH/system/my_product/etc/resourcemanager.xml
cp_ch -r /my_product/etc/sound_trigger_platform_info.xml/ $MODPATH/system/my_product/etc/sound_trigger_platform_info.xml/
cp_ch -r /my_product/etc/dolby/ $MODPATH/system/my_product/etc/dolby/


  for OATRACE in ${ATRACE}; do
	ATRAC="$MODPATH$(echo $OATRACE | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OATRACE $ATRAC
	sed -i 's/\t/  /g' $ATRAC
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $ATRAC
	done

  for OQCVIRT in ${QCVIRTJ}; do
	QCVIRT="$MODPATH$(echo $OQCVIRT | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OQCVIRT $QCVIRT
	sed -i 's/\t/  /g' $QCVIRT
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $QCVIRT
	done

  for OACCXML in ${ACCXML}; do
	ACCXM="$MODPATH$(echo $OACCXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OACCXML $ACCXM
	sed -i 's/\t/  /g' $ACCXM
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $ACCXM
	done

  for OSNDTRPL in ${SNDTRPL}; do
	SNDTRP="$MODPATH$(echo $OSNDTRPL | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OSNDTRPL $SNDTRP
	sed -i 's/\t/  /g' $SNDTRP
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $SNDTRP
	done

  for OMEDCX in ${MEDCA}; do
	MEDCX="$MODPATH$(echo $OMEDCX | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OMEDCX $MEDCX
	sed -i 's/\t/  /g' $MEDCX
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $MEDCX
	done

  for OMIX in ${MPATHS}; do
	MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OMIX $MIX
	sed -i 's/\t/  /g' $MIX
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $MIX
	done

  for OA2DPXML in ${A2DPXML}; do
	A2DPXM="$MODPATH$(echo $OA2DPXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OA2DPXML $A2DPXM
	sed -i 's/\t/  /g' $A2DPXM
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $A2DPXM
	done

  for OBTQTIXML in ${BTQTIXML}; do
	BTQTIXM="$MODPATH$(echo $OBTQTIXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OBTQTIXML $BTQTIXM
	sed -i 's/\t/  /g' $BTQTIXM
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $BTQTIXM
	done

  for OVEHXML in ${VEHXML}; do
	VEHXM="$MODPATH$(echo $OVEHXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OVEHXML $VEHXM
	sed -i 's/\t/  /g' $VEHXM
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $VEHXM
	done

  for OVIRTXML in ${VIRTXML}; do
	VIRTXM="$MODPATH$(echo $OVIRTXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OVIRTXML $VIRTXM
	sed -i 's/\t/  /g' $VIRTXM
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $VIRTXM
	done

  for OUSBXML in ${USBXML}; do
	USBXM="$MODPATH$(echo $OUSBXML| sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OUSBXML $USBXM
	sed -i 's/\t/  /g' $USBXM
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $USBXM
	done

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OAPCXM $APCXM
	sed -i 's/\t/  /g' $APCXM
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $APCXM
	done

  for OAPIOCXM in ${APIOCXML}; do
	APIOCXM="$MODPATH$(echo $OAPIOCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OAPIOCXM $APIOCXM
	sed -i 's/\t/  /g' $APIOCXM
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $APIOCXM
	done

  for ODEVF in ${DEVF}; do
	AODEVF="$MODPATH$(echo $ODEVF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$ODEVF $AODEVF
	sed -i 's/\t/  /g' $AODEVF
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $AODEVF
	done

  for OAPLI in ${APINF}; do
	APLI="$MODPATH$(echo $OAPLI | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OAPLI $APLI
	sed -i 's/\t/  /g' $APLI
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $APLI
	done


  for OACONF in ${ACONFS}; do
	ACONF="$MODPATH$(echo $OACONF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OACONF $ACONF
	sed -i 's/\t/  /g' $ACONF
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $ACONF
	done


  for OBTCONF in ${BTCONF}; do
	BTCON="$MODPATH$(echo $OBTCONF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OBTCONF $BTCON
	sed -i 's/\t/  /g' $BTCON
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $BTCON
	done
	
  for OBTCONF2 in ${BTCONF2}; do
	BTCON2="$MODPATH$(echo $OBTCONF2 | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OBTCONF2 $BTCON2
	sed -i 's/\t/  /g' $BTCON2
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $BTCON2
	done


  for ODAXXML in ${DAXXML}; do
	DAXXM="$MODPATH$(echo $ODAXXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$ODAXXML $DAXXM
	sed -i 's/\t/  /g' $DAXXM
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $DAXXM
	done

  for OACCXML in ${ACCXML}; do
	ACCXM="$MODPATH$(echo $OACCXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/<kara_app_name_list>/a\
        <com.neutroncode.mp/>\
        <ru.yandex.music/>\
        <com.hitrolab.audioeditor/>\
        <com.google.android.youtube/>\
        <com.google.android.youtube.music/>\
        <com.mxtech.videoplayer/>\
        <com.mxtech.videoplayer.pro/>\
        <com.spotify.music/>\
        <com.apple.android.music/>\
        <deezer.android.app/>\
        <com.vkontakte.android/>\
        <com.uma.musicvk/>\
        <com.vk.clips/>\
        <ru.ok.android/>\
        <com.facebook.katana/>\
        <com.instagram.android/>\
        <tunein.player/>\
        <free.zaycev.net/>\
        <fm.last.android/>\
        <com.aspiro.tidal/>\
        <com.qobuz.music/>\
        <com.extreamsd.usbaudioplayerpro/>\
        <com.zvooq.openplay/>\
        <com.jetappfactory.jetaudio/>\
        <com.jetappfactory.jetaudioplus/>\
		<ru.mts.music.android/>\
        <com.maxmpz.audioplayer/>' $ACCXM
	sed -i '/<record_unsilence_app_name_list>/a\
        <com.SearingMedia.Parrot/>\
        <com.hitrolab.audioeditor/>' $ACCXM
	sed -i '/^ *#/d; /^ *$/d' $ACCXM
	done

  for OBTCONF in ${BTCONF}; do
	BTCON="$MODPATH$(echo $OBTCONF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/aacFrameCtlEnabled = false/aacFrameCtlEnabled = true/g' $BTCON
	sed -i '/^ *#/d; /^ *$/d' $BTCON
	done

  for OBTCONF2 in ${BTCONF2}; do
	BTCON2="$MODPATH$(echo $OBTCONF2 | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/TraceConf=true/TraceConf=false/g' $BTCON2
	sed -i 's/TRC_BTM=2/TRC_BTM=0/g' $BTCON2
	sed -i 's/TRC_HCI=2/TRC_HCI=0/g' $BTCON2
	sed -i 's/TRC_L2CAP=2/TRC_L2CAP=0/g' $BTCON2
	sed -i 's/TRC_RFCOMM=2/TRC_RFCOMM=0/g' $BTCON2
	sed -i 's/TRC_OBEX=2/TRC_OBEX=0/g' $BTCON2
	sed -i 's/TRC_AVCT=2/TRC_AVCT=0/g' $BTCON2
	sed -i 's/TRC_AVDT=2/TRC_AVDT=0/g' $BTCON2
	sed -i 's/TRC_AVRC=2/TRC_AVRC=0/g' $BTCON2
	sed -i 's/TRC_AVDT_SCB=2/TRC_AVDT_SCB=0/g' $BTCON2
	sed -i 's/TRC_AVDT_CCB=2/TRC_AVDT_CCB=0/g' $BTCON2
	sed -i 's/TRC_A2D=2/TRC_A2D=0/g' $BTCON2
	sed -i 's/TRC_SDP=2/TRC_SDP=0/g' $BTCON2
	sed -i 's/TRC_SMP=2/TRC_SMP=0/g' $BTCON2
	sed -i 's/TRC_BTAPP=2/TRC_BTAPP=0/g' $BTCON2
	sed -i 's/TRC_BTIF=2/TRC_BTIF=0/g' $BTCON2
	sed -i 's/TRC_BNEP=2/TRC_BNEP=0/g' $BTCON2
	sed -i 's/TRC_PAN=2/TRC_PAN=0/g' $BTCON2
	sed -i 's/TRC_HID_HOST=2/TRC_HID_HOST=0/g' $BTCON2
	sed -i 's/TRC_HID_DEV=2/TRC_HID_DEV=0/g' $BTCON2
	sed -i 's/TRC_GATT=2/TRC_GATT=0/g' $BTCON2
	sed -i '/^ *#/d; /^ *$/d' $BTCON2
	done

  for ODAXXML in ${DAXXML}; do
	DAXXM="$MODPATH$(echo $ODAXXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/low-filter-mode value="1"/low-filter-mode value="0"/g' $DAXXM
	sed -i 's/band-filter-mode value="1"/band-filter-mode value="0"/g' $DAXXM
	sed -i 's/middle-filter-mode value="1"/middle-filter-mode value="0"/g' $DAXXM
	sed -i 's/height-filter-mode value="1"/height-filter-mode value="0"/g' $DAXXM
	sed -i 's/volume-leveler-compressor-enable value="true"/volume-leveler-compressor-enable value="false"/g' $DAXXM
	sed -i 's/hearing-protection-enable value="true"/hearing-protection-enable value="false"/g' $DAXXM
	sed -i 's/regulator-speaker-dist-enable value="true"/regulator-speaker-dist-enable value="false"/g' $DAXXM
	sed -i 's/bass-mbdrc-enable value="true"/bass-mbdrc-enable value="false"/g' $DAXXM
	sed -i 's/bass-extraction-enable value="true"/bass-extraction-enable value="false"/g' $DAXXM
	sed -i 's/reverb-suppression-enable value="true"/reverb-suppression-enable value="false"/g' $DAXXM
	sed -i 's/audio-optimizer-enable value="true"/audio-optimizer-enable value="false"/g' $DAXXM
	sed -i 's/regulator-sibilance-suppress-enable value="true"/regulator-sibilance-suppress-enable value="false"/g' $DAXXM
	sed -i 's/ieq-enable value="true"/ieq-enable value="false"/g' $DAXXM
	sed -i 's/complex-equalizer-enable value="true"/complex-equalizer-enable value="false"/g' $DAXXM
	sed -i 's/virtual-bass-process-enable value="true"/virtual-bass-process-enable value="false"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="1"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="2"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="3"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="4"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="5"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="6"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="7"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="8"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="9"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="10"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="11"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="12"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="13"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="14"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="15"/global_setting virtual_bass_process="0"/g' $DAXXM
#	sed -i 's/virtualizer-enable value="false"/virtualizer-enable value="true"/g' $DAXXM
	sed -i 's/bass-enhancer-enable value="false"/bass-enhancer-enable value="true"/g' $DAXXM
	sed -i 's/graphic-equalizer-enable value="false"/graphic-equalizer-enable value="true"/g' $DAXXM
	sed -i 's/surround-decoder-enable value="false"/surround-decoder-enable value="true"/g' $DAXXM
	sed -i 's/volume-leveler-enable value="false"/volume-leveler-enable value="true"/g' $DAXXM
	sed -i 's/tuned_rate="48000"/tuned_rate="192000"/g' $DAXXM
	sed -i '/^ *#/d; /^ *$/d' $DAXXM
	done

  for OSNDTRPL in ${SNDTRPL}; do
	SNDTRP="$MODPATH$(echo $OSNDTRPL | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/context_manager_enable="false"/context_manager_enable="true"/g' $SNDTRP
	sed -i 's/low_latency_bargein_enable="true"/low_latency_bargein_enable="false"/g' $SNDTRP
	sed -i '/^ *#/d; /^ *$/d' $SNDTRP
	done

  for OMEDCX in ${MEDCA}; do
	MEDCX="$MODPATH$(echo $OMEDCX | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/name="sample-rate" ranges="8000,11025,12000,16000,22050,24000,32000,44100,48000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="32000,44100,48000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="48000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="7350,8000,11025,12000,16000,22050,24000,32000,44100,48000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="8000-48000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="8000-96000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="sample-rate" ranges="8000-192000"/name="sample-rate" ranges="1-655350"/g' $MEDCX
	sed -i 's/name="bitrate-modes" value="CBR"/name="bitrate-modes" value="CQ"/g' $MEDCX
	sed -i 's/name="complexity" range="0-10"  default="9"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-10"  default="8"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-10"  default="7"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-10"  default="6"/name="complexity" range="0-10"  default="10"/g' $MEDCX
	sed -i 's/name="complexity" range="0-8"  default="7"/name="complexity" range="0-8"  default="8"/g' $MEDCX
	sed -i 's/name="complexity" range="0-8"  default="6"/name="complexity" range="0-8"  default="8"/g' $MEDCX
	sed -i 's/name="complexity" range="0-8"  default="5"/name="complexity" range="0-8"  default="8"/g' $MEDCX
	sed -i 's/name="complexity" range="0-8"  default="4"/name="complexity" range="0-8"  default="8"/g' $MEDCX
	sed -i 's/name="quality" range="0-80"  default="100"/name="quality" range="0-100"  default="100"/g' $MEDCX
	sed -i 's/name="bitrate" range="8000-320000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="8000-960000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="32000-500000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="6000-510000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="1-10000000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="500-512000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="32000-640000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="32000-6144000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="16000-2688000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i 's/name="bitrate" range="64000"/name="bitrate" range="1-21000000"/g' $MEDCX
	sed -i '/^ *#/d; /^ *$/d' $MEDCX
	done

  for OAPLI in ${APINF}; do
	APLI="$MODPATH$(echo $OAPLI | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/<bit_width_configs/a\
    <device name="SND_DEVICE_OUT_SPEAKER" bit_width="24"/>\
    <device name="SND_DEVICE_OUT_HEADPHONES" bit_width="24"/>\
    <device name="SND_DEVICE_OUT_SPEAKER_REVERSE" bit_width="24"/>\
    <device name="SND_DEVICE_OUT_SPEAKER_PROTECTED" bit_width="24"/>\
    <device name="SND_DEVICE_OUT_HEADPHONES_44_1" bit_width="24"/>\
    <device name="SND_DEVICE_OUT_GAME_SPEAKER" bit_width="24"/>\
    <device name="SND_DEVICE_OUT_GAME_HEADPHONES" bit_width="24"/>\
    <device name="SND_DEVICE_OUT_BT_A2DP" bit_width="24"/>' $APLI
	sed -i 's/name="SND_DEVICE_OUT_SPEAKER" bit_width="16"/name="SND_DEVICE_OUT_SPEAKER" bit_width="24"/g' $APLI
	sed -i '/^ *#/d; /^ *$/d' $APLI
	done

  for OA2DPXML in ${A2DPXML}; do
	A2DPXM="$MODPATH$(echo $OA2DPXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100,48000,88200,96000"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000"/g' $A2DPXM
	sed -i 's/samplingRates="44100 48000 88200 96000"/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000"/g' $A2DPXM
	sed -i 's/samplingRates="44100,48000,96000"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000"/g' $A2DPXM
	sed -i 's/samplingRates="44100 48000 96000"/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000"/g' $A2DPXM
	sed -i 's/ AUDIO_FORMAT_FORCE_AOSP_LL//g' $A2DPXM
	sed -i 's/AUDIO_FORMAT_FORCE_AOSP_LL//g' $A2DPXM
	sed -i 's/AUDIO_FORMAT_FORCE_AOSP/AUDIO_FORMAT_FORCE_AOSP AUDIO_FORMAT_FORCE_AOSP_LL/g' $A2DPXM
	sed -i 's/"AUDIO_DEVICE_OUT_BLUETOOTH_A2DP" role="sink">/"AUDIO_DEVICE_OUT_BLUETOOTH_A2DP" role="sink" encodedFormats="AUDIO_FORMAT_FORCE_AOSP AUDIO_FORMAT_FORCE_AOSP_LL">/g' $A2DPXM
	sed -i 's/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_HEADPHONES" role="sink">/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_HEADPHONES" role="sink" encodedFormats="AUDIO_FORMAT_FORCE_AOSP AUDIO_FORMAT_FORCE_AOSP_LL">/g' $A2DPXM
	sed -i 's/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_SPEAKER" role="sink">/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_SPEAKER" role="sink" encodedFormats="AUDIO_FORMAT_FORCE_AOSP AUDIO_FORMAT_FORCE_AOSP_LL">/g' $A2DPXM
	sed -i '/^ *#/d; /^ *$/d' $A2DPXM
	done

  for OBTQTIXML in ${BTQTIXML}; do
	BTQTIXM="$MODPATH$(echo $OBTQTIXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100,48000,88200,96000"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000"/g' $BTQTIXM
	sed -i 's/samplingRates="44100 48000 88200 96000"/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000"/g' $BTQTIXM
	sed -i 's/samplingRates="44100,48000,96000"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000"/g' $BTQTIXM
	sed -i 's/samplingRates="44100 48000 96000"/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000"/g' $BTQTIXM
	sed -i 's/ AUDIO_FORMAT_FORCE_AOSP_LL//g' $BTQTIXM
	sed -i 's/AUDIO_FORMAT_FORCE_AOSP_LL//g' $BTQTIXM
	sed -i 's/AUDIO_FORMAT_FORCE_AOSP/AUDIO_FORMAT_FORCE_AOSP AUDIO_FORMAT_FORCE_AOSP_LL/g' $BTQTIXM
	sed -i 's/"AUDIO_DEVICE_OUT_BLUETOOTH_A2DP" role="sink">/"AUDIO_DEVICE_OUT_BLUETOOTH_A2DP" role="sink" encodedFormats="AUDIO_FORMAT_FORCE_AOSP AUDIO_FORMAT_FORCE_AOSP_LL">/g' $BTQTIXM
	sed -i 's/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_HEADPHONES" role="sink">/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_HEADPHONES" role="sink" encodedFormats="AUDIO_FORMAT_FORCE_AOSP AUDIO_FORMAT_FORCE_AOSP_LL">/g' $BTQTIXM
	sed -i 's/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_SPEAKER" role="sink">/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP_SPEAKER" role="sink" encodedFormats="AUDIO_FORMAT_FORCE_AOSP AUDIO_FORMAT_FORCE_AOSP_LL">/g' $BTQTIXM
	sed -i '/^ *#/d; /^ *$/d' $BTQTIXM
	done

  for OUSBXML in ${USBXML}; do
	USBXM="$MODPATH$(echo $OUSBXML| sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100"/samplingRates="192000"/g' $USBXM
	sed -i '/^ *#/d; /^ *$/d' $USBXM
	done

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/AUDIO_FORMAT_PCM_32_BIT/AUDIO_FORMAT_PCM_FLOAT/g' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO,AUDIO_CHANNEL_OUT_MONO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO AUDIO_CHANNEL_OUT_MONO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_MONO,AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_MONO AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_RAW/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"\
                             samplingRates="48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i 's/ AUDIO_FORMAT_FORCE_AOSP_LL//g' $APCXM
	sed -i 's/AUDIO_FORMAT_FORCE_AOSP_LL//g' $APCXM
	sed -i 's/AUDIO_FORMAT_FORCE_AOSP/AUDIO_FORMAT_FORCE_AOSP AUDIO_FORMAT_FORCE_AOSP_LL/g' $APCXM
	sed -i 's/ AUDIO_FORMAT_LHDC_LL//g' $APCXM
	sed -i 's/AUDIO_FORMAT_LHDC_LL//g' $APCXM
	sed -i 's/AUDIO_FORMAT_LHDC/AUDIO_FORMAT_LHDC AUDIO_FORMAT_LHDC_LL/g' $APCXM
	sed -i 's/speaker_drc_enabled="true"/speaker_drc_enabled="false"/g' $APCXM
	sed -i 's/samplingRates="32000,44100,48000"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000,352800,384000"/g' $APCXM
	sed -i 's/samplingRates="32000,44100,48000,64000,88200,96000,128000,176400,192000"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000,352800,384000"/g' $APCXM
	sed -i 's/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000,352800,384000"/g' $APCXM
	sed -i 's/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000,352800,384000"/g' $APCXM
	sed -i 's/samplingRates="44100,48000,96000"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000"/g' $APCXM
	sed -i 's/samplingRates="44100,48000,88200,96000"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000,128000,176400,192000"/g' $APCXM
	sed -i 's/samplingRates="32000 44100 48000"/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000 352800 384000"/g' $APCXM
	sed -i 's/samplingRates="32000 44100 48000 64000 88200 96000 128000 176400 192000"/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000 352800 384000"/g' $APCXM
	sed -i 's/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000"/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000 352800 384000"/g' $APCXM
	sed -i 's/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000"/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000 352800 384000"/g' $APCXM
	sed -i 's/samplingRates="44100 48000 96000"/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000"/g' $APCXM
	sed -i 's/samplingRates="44100 48000 88200 96000"/samplingRates="8000 11025 12000 16000 22050 24000 32000 44100 48000 64000 88200 96000 128000 176400 192000"/g' $APCXM
	sed -i 's/channelMasks="AUDIO_CHANNEL_OUT_5POINT1,AUDIO_CHANNEL_OUT_6POINT1,AUDIO_CHANNEL_OUT_7POINT1"/channelMasks="AUDIO_CHANNEL_OUT_MONO,AUDIO_CHANNEL_OUT_STEREO,AUDIO_CHANNEL_OUT_2POINT1,AUDIO_CHANNEL_OUT_QUAD,AUDIO_CHANNEL_OUT_PENTA,AUDIO_CHANNEL_OUT_5POINT1,AUDIO_CHANNEL_OUT_6POINT1,AUDIO_CHANNEL_OUT_7POINT1"/g' $APCXM
	sed -i 's/channelMasks="AUDIO_CHANNEL_OUT_5POINT1 AUDIO_CHANNEL_OUT_6POINT1 AUDIO_CHANNEL_OUT_7POINT1"/channelMasks="AUDIO_CHANNEL_OUT_MONO AUDIO_CHANNEL_OUT_STEREO AUDIO_CHANNEL_OUT_2POINT1 AUDIO_CHANNEL_OUT_QUAD AUDIO_CHANNEL_OUT_PENTA AUDIO_CHANNEL_OUT_5POINT1 AUDIO_CHANNEL_OUT_6POINT1 AUDIO_CHANNEL_OUT_7POINT1"/g' $APCXM
	sed -i 's/channelMasks="AUDIO_CHANNEL_OUT_STEREO,AUDIO_CHANNEL_OUT_MONO"/channelMasks="AUDIO_CHANNEL_OUT_MONO,AUDIO_CHANNEL_OUT_STEREO,AUDIO_CHANNEL_OUT_2POINT1,AUDIO_CHANNEL_OUT_QUAD,AUDIO_CHANNEL_OUT_PENTA,AUDIO_CHANNEL_OUT_5POINT1,AUDIO_CHANNEL_OUT_6POINT1,AUDIO_CHANNEL_OUT_7POINT1"/g' $APCXM
	sed -i 's/channelMasks="AUDIO_CHANNEL_OUT_STEREO AUDIO_CHANNEL_OUT_MONO"/channelMasks="AUDIO_CHANNEL_OUT_MONO AUDIO_CHANNEL_OUT_STEREO AUDIO_CHANNEL_OUT_2POINT1 AUDIO_CHANNEL_OUT_QUAD AUDIO_CHANNEL_OUT_PENTA AUDIO_CHANNEL_OUT_5POINT1 AUDIO_CHANNEL_OUT_6POINT1 AUDIO_CHANNEL_OUT_7POINT1"/g' $APCXM
	sed -i 's/channelMasks="AUDIO_CHANNEL_OUT_MONO,AUDIO_CHANNEL_OUT_STEREO,AUDIO_CHANNEL_OUT_2POINT1,AUDIO_CHANNEL_OUT_QUAD,AUDIO_CHANNEL_OUT_PENTA,AUDIO_CHANNEL_OUT_5POINT1"/channelMasks="AUDIO_CHANNEL_OUT_MONO,AUDIO_CHANNEL_OUT_STEREO,AUDIO_CHANNEL_OUT_2POINT1,AUDIO_CHANNEL_OUT_QUAD,AUDIO_CHANNEL_OUT_PENTA,AUDIO_CHANNEL_OUT_5POINT1,AUDIO_CHANNEL_OUT_6POINT1,AUDIO_CHANNEL_OUT_7POINT1"/g' $APCXM
	sed -i 's/channelMasks="AUDIO_CHANNEL_OUT_MONO AUDIO_CHANNEL_OUT_STEREO AUDIO_CHANNEL_OUT_2POINT1 AUDIO_CHANNEL_OUT_QUAD AUDIO_CHANNEL_OUT_PENTA AUDIO_CHANNEL_OUT_5POINT1"/channelMasks="AUDIO_CHANNEL_OUT_MONO AUDIO_CHANNEL_OUT_STEREO AUDIO_CHANNEL_OUT_2POINT1 AUDIO_CHANNEL_OUT_QUAD AUDIO_CHANNEL_OUT_PENTA AUDIO_CHANNEL_OUT_5POINT1 AUDIO_CHANNEL_OUT_6POINT1 AUDIO_CHANNEL_OUT_7POINT1"/g' $APCXM
	sed -i 's/mixPort name="primary input" role="sink" maxOpenCount="0" maxActiveCount="0"/mixPort name="primary input" role="sink"/g' $APCXM
	sed -i 's/mixPort name="primary input" role="sink" maxOpenCount="0" maxActiveCount="1"/mixPort name="primary input" role="sink"/g' $APCXM
	sed -i 's/mixPort name="primary input" role="sink" maxOpenCount="0" maxActiveCount="2"/mixPort name="primary input" role="sink"/g' $APCXM
	sed -i 's/mixPort name="primary input" role="sink" maxOpenCount="1" maxActiveCount="0"/mixPort name="primary input" role="sink"/g' $APCXM
	sed -i 's/mixPort name="primary input" role="sink" maxOpenCount="1" maxActiveCount="1"/mixPort name="primary input" role="sink"/g' $APCXM
	sed -i 's/mixPort name="primary input" role="sink" maxOpenCount="1" maxActiveCount="2"/mixPort name="primary input" role="sink"/g' $APCXM
	sed -i 's/mixPort name="primary input" role="sink" maxOpenCount="2" maxActiveCount="0"/mixPort name="primary input" role="sink"/g' $APCXM
	sed -i 's/mixPort name="primary input" role="sink" maxOpenCount="2" maxActiveCount="1"/mixPort name="primary input" role="sink"/g' $APCXM
	sed -i 's/mixPort name="primary input" role="sink" maxOpenCount="2" maxActiveCount="2"/mixPort name="primary input" role="sink"/g' $APCXM
	sed -i '/AIST/,+3d' $APCXM
	sed -i '/^ *#/d; /^ *$/d' $APCXM
	done

  for OAPIOCXM in ${APIOCXML}; do
	APIOCXM="$MODPATH$(echo $OAPIOCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/sampling_rates 44100|48000|88200|96000|176400|192000|352800|384000/sampling_rates 8000|11025|12000|16000|22050|24000|32000|44100|48000|88200|96000|176400|192000|352800|384000/g' $APIOCXM
	sed -i 's/sampling_rates 32000|44100|48000|88200|96000|176400|192000|352800/sampling_rates 8000|11025|12000|16000|22050|24000|32000|44100|48000|88200|96000|176400|192000|352800|384000/g' $APIOCXM
	sed -i 's/AUDIO_FORMAT_PCM_16_BIT_OFFLOAD|//g' $APIOCXM
	sed -i 's/AUDIO_FORMAT_PCM_24_BIT_OFFLOAD|//g' $APIOCXM
	sed -i 's/AUDIO_FORMAT_PCM_FLOAT_OFFLOAD|//g' $APIOCXM
	sed -i 's/AUDIO_FORMAT_PCM_32_BIT/AUDIO_FORMAT_PCM_FLOAT/g' $APIOCXM
	sed -i '/AUDIO_FORMAT_MP3/a\
AIST' $APIOCXM
	sed -i '/AIST/,+1d' $APIOCXM
	sed -i '/AUDIO_FORMAT_MP3/a\
    sampling_rates 8000|11025|12000|16000|22050|24000|32000|44100|48000|88200|96000|176400|192000|352800|384000' $APIOCXM
	sed -i '/default_24/,+6d' $APIOCXM
	sed -i '/proaudio/,+6d' $APIOCXM
	sed -i '/^outputs/a\
  default_24 {\
    flags AUDIO_OUTPUT_FLAG_PRIMARY\
    formats AUDIO_FORMAT_PCM_FLOAT\
    sampling_rates 48000\
    bit_width 24\
    app_type 69937\
  }\
  default_24bit {\
    flags AUDIO_OUTPUT_FLAG_PRIMARY\
    formats AUDIO_FORMAT_PCM_FLOAT\
    sampling_rates 48000\
    bit_width 24\
    app_type 69937\
  }\
  proaudio {\
    flags AUDIO_OUTPUT_FLAG_FAST\
    formats AUDIO_FORMAT_PCM_FLOAT\
    sampling_rates 48000\
    bit_width 32\
    app_type 69943\
  }' $APIOCXM
	sed -i '/^ *#/d; /^ *$/d' $APIOCXM
	done

  for ODEVF in ${DEVF}; do
	AODEVF="$MODPATH$(echo $ODEVF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/name="btdebug_enabled">true</name="btdebug_enabled">false</g' $AODEVF
	sed -i 's/name="support_ble_oobhelper">false</name="support_ble_oobhelper">true</g' $AODEVF
	sed -i 's/name="support_record_param">false</name="support_record_param">true</g' $AODEVF
	sed -i 's/name="support_interview_record_param">false</name="support_interview_record_param">true</g' $AODEVF
	sed -i 's/name="support_hd_record_param">false</name="support_hd_record_param">true</g' $AODEVF
	sed -i 's/name="support_voip_record">false</name="support_voip_record">true</g' $AODEVF
	sed -i 's/name="support_dolby">false</name="support_dolby">true</g' $AODEVF
	sed -i 's/name="support_hifi">true</name="support_hifi">false</g' $AODEVF
	sed -i 's/name="support_lhdc_offload">false</name="support_lhdc_offload">true</g' $AODEVF
	sed -i 's/name="support_a2dp_latency">false</name="support_a2dp_latency">true</g' $AODEVF
	sed -i 's/name="support_sound_assist">false</name="support_sound_assist">true</g' $AODEVF
	sed -i 's/name="support_new_silentmode">false</name="support_new_silentmode">true</g' $AODEVF
	sed -i 's/name="support_24bit_record">false</name="support_24bit_record">true</g' $AODEVF
	sed -i 's/name="support_audio_loopback">false</name="support_audio_loopback">true</g' $AODEVF
	sed -i 's/name="support_adv_audio_unicast">true</name="support_adv_audio_unicast">false</g' $AODEVF
	sed -i 's/name="support_adv_audio_bca">true</name="support_adv_audio_bca">false</g' $AODEVF
	sed -i 's/name="support_adv_audio_bcs">true</name="support_adv_audio_bcs">false</g' $AODEVF
	sed -i 's/name="support_camera_audio_focus">false</name="support_camera_audio_focus">true</g' $AODEVF
	sed -i 's/name="support_audio_share">false</name="support_audio_share">true</g' $AODEVF
	sed -i '/<features>/a\
	<bool name="support_voip_record">true</bool>\
	<bool name="support_ble_oobhelper">true</bool>\
	<bool name="support_audio_share">true</bool>\
	<bool name="support_24bit_record">true</bool>' $AODEVF
	sed -i '/^ *#/d; /^ *$/d' $AODEVF
	done

ui_print "*    [Fix 24/FLOAT bit 48/96 kHz Audio Output]    *"
ui_print "***************************************************"
ui_print "* !Attention! Sound failure possible or bootloop! *"
ui_print "*If, when this item is set, the sound is distorted*"
ui_print "*    or becomes flat, or does not sound at all    *"
ui_print "*     Reinstalls the module without this item.    *"
ui_print "***************************************************"
ui_print "* [Vol Up = 24/FLOAT bit |      Vol Down = Stock] *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "***************************************************"
ui_print "* [Vol Up = FLOAT bit]   |      Vol Down = 24 bit *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "***************************************************"
ui_print "*                 ->[FLOAT bit]<-                 *"
ui_print "***************************************************"
ui_print "* [Vol Up = 96 kHz       |     Vol Down = 48 kHz] *"
ui_print "***************************************************"

if $VKSEL; then

	prop_process $MODPATH/common/FLOAT.prop

ui_print "*    ->[Fixing FLOAT bit 96kHz Audio Output]<-    *"
ui_print "***************************************************"

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO,AUDIO_CHANNEL_OUT_MONO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO AUDIO_CHANNEL_OUT_MONO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_MONO,AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_MONO AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LHDC/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LHDC/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LDAC"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LDAC"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LC3"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LC3"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_FORCE_AOSP"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_FORCE_AOSP"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/encodedFormats="ldac_a2dp"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="ldac_a2dp"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/name="usb_accessory output" role="source"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/name="usb_accessory output" role="source"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_DEEP_BUFFER/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"\
                             samplingRates="96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_VIRTUAL_DEEP_BUFFER/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"\
                             samplingRates="96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_RAW/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"\
                             samplingRates="96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i '/AIST/,+3d' $APCXM
	sed -i '/^ *#/d; /^ *$/d' $APCXM
	done

  for OAPIOCXM in ${APIOCXML}; do
	APIOCXM="$MODPATH$(echo $OAPIOCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/deep_buffer_24/,+6d' $APIOCXM
	sed -i '/proaudio/,+6d' $APIOCXM
	sed -i '/^outputs/a\
  deep_buffer_24 {\
    flags AUDIO_OUTPUT_FLAG_DEEP_BUFFER\
    formats AUDIO_FORMAT_PCM_FLOAT\
    sampling_rates 96000\
    bit_width 24\
    app_type 69940\
  }\
  deep_buffer_24bit {\
    flags AUDIO_OUTPUT_FLAG_DEEP_BUFFER\
    formats AUDIO_FORMAT_PCM_FLOAT\
    sampling_rates 96000\
    bit_width 24\
    app_type 69940\
  }\
  proaudio {\
    flags AUDIO_OUTPUT_FLAG_FAST\
    formats AUDIO_FORMAT_PCM_FLOAT\
    sampling_rates 96000\
    bit_width 32\
    app_type 69943\
  }' $APIOCXM
	sed -i '/^ *#/d; /^ *$/d' $APIOCXM
	done

  for OA2DPXML in ${A2DPXML}; do
	A2DPXM="$MODPATH$(echo $OA2DPXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100"/samplingRates="96000"/g' $A2DPXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
AI2ST' $A2DPXM
	sed -i '/AI2ST/,+1d' $A2DPXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $A2DPXM
	sed -i '/^ *#/d; /^ *$/d' $A2DPXM
	done

  for OBTQTIXML in ${BTQTIXML}; do
	BTQTIXM="$MODPATH$(echo $OBTQTIXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100"/samplingRates="96000"/g' $BTQTIXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
AI2ST' $BTQTIXM
	sed -i '/AI2ST/,+1d' $BTQTIXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $BTQTIXM
	sed -i '/^ *#/d; /^ *$/d' $BTQTIXM
	done

  for OUSBXML in ${USBXML}; do
	USBXM="$MODPATH$(echo $OUSBXML| sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $USBXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
AI2ST' $USBXM
	sed -i '/AI2ST/,+1d' $USBXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $USBXM
	sed -i '/name="usb_accessory output" role="source"/a\
AI2ST' $USBXM
	sed -i '/AI2ST/,+1d' $USBXM
	sed -i '/name="usb_accessory output" role="source"/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $USBXM
	sed -i '/^ *#/d; /^ *$/d' $USBXM
	done

else

	prop_process $MODPATH/common/FLOAT.prop

ui_print "*   ->[Fixing FLOAT bit 48 kHz Audio Output]<-    *"
ui_print "***************************************************"

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO,AUDIO_CHANNEL_OUT_MONO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO AUDIO_CHANNEL_OUT_MONO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_MONO,AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_MONO AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LHDC/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LHDC/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LDAC"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LDAC"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LC3"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LC3"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_FORCE_AOSP"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_FORCE_AOSP"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/encodedFormats="ldac_a2dp"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="ldac_a2dp"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/name="usb_accessory output" role="source"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/name="usb_accessory output" role="source"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_DEEP_BUFFER/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"\
                             samplingRates="48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_VIRTUAL_DEEP_BUFFER/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"\
                             samplingRates="48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i '/AIST/,+3d' $APCXM
	sed -i '/^ *#/d; /^ *$/d' $APCXM
	done

  for OAPIOCXM in ${APIOCXML}; do
	APIOCXM="$MODPATH$(echo $OAPIOCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/deep_buffer_24/,+6d' $APIOCXM
	sed -i '/^outputs/a\
  deep_buffer_24 {\
    flags AUDIO_OUTPUT_FLAG_DEEP_BUFFER\
    formats AUDIO_FORMAT_PCM_FLOAT\
    sampling_rates 48000\
    bit_width 24\
    app_type 69940\
  }\
  deep_buffer_24bit {\
    flags AUDIO_OUTPUT_FLAG_DEEP_BUFFER\
    formats AUDIO_FORMAT_PCM_FLOAT\
    sampling_rates 48000\
    bit_width 24\
    app_type 69940\
  }' $APIOCXM
	sed -i '/^ *#/d; /^ *$/d' $APIOCXM
	done

  for OA2DPXML in ${A2DPXML}; do
	A2DPXM="$MODPATH$(echo $OA2DPXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100"/samplingRates="48000"/g' $A2DPXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
AI2ST' $A2DPXM
	sed -i '/AI2ST/,+1d' $A2DPXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $A2DPXM
	sed -i '/^ *#/d; /^ *$/d' $A2DPXM
	done

  for OBTQTIXML in ${BTQTIXML}; do
	BTQTIXM="$MODPATH$(echo $OBTQTIXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100"/samplingRates="48000"/g' $BTQTIXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
AI2ST' $BTQTIXM
	sed -i '/AI2ST/,+1d' $BTQTIXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $BTQTIXM
	sed -i '/^ *#/d; /^ *$/d' $BTQTIXM
	done

  for OUSBXML in ${USBXML}; do
	USBXM="$MODPATH$(echo $OUSBXML| sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $USBXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
AI2ST' $USBXM
	sed -i '/AI2ST/,+1d' $USBXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $USBXM
	sed -i '/name="usb_accessory output" role="source"/a\
AI2ST' $USBXM
	sed -i '/AI2ST/,+1d' $USBXM
	sed -i '/name="usb_accessory output" role="source"/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $USBXM
	sed -i '/^ *#/d; /^ *$/d' $USBXM
	done

fi

else
ui_print "***************************************************"
ui_print "*                   ->[24bit]<-                   *"
ui_print "***************************************************"
ui_print "* [Vol Up = 96 kHz       |     Vol Down = 48 kHz] *"
ui_print "***************************************************"

if $VKSEL; then

	prop_process $MODPATH/common/24.prop

ui_print "*     ->[Fixing 24 bit 96 kHz Audio Output]<-     *"
ui_print "***************************************************"

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO,AUDIO_CHANNEL_OUT_MONO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO AUDIO_CHANNEL_OUT_MONO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_MONO,AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_MONO AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LHDC/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LHDC/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LDAC"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LDAC"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LC3"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LC3"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_FORCE_AOSP"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_FORCE_AOSP"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $APCXM
	sed -i '/encodedFormats="ldac_a2dp"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="ldac_a2dp"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $APCXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/name="usb_accessory output" role="source"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/name="usb_accessory output" role="source"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_DEEP_BUFFER/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"\
                             samplingRates="96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_VIRTUAL_DEEP_BUFFER/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"\
                             samplingRates="96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_RAW/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"\
                             samplingRates="96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i '/AIST/,+3d' $APCXM
	sed -i '/^ *#/d; /^ *$/d' $APCXM
	done

  for OAPIOCXM in ${APIOCXML}; do
	APIOCXM="$MODPATH$(echo $OAPIOCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/deep_buffer_24/,+6d' $APIOCXM
	sed -i '/proaudio/,+6d' $APIOCXM
	sed -i '/^outputs/a\
  deep_buffer_24 {\
    flags AUDIO_OUTPUT_FLAG_DEEP_BUFFER\
    formats AUDIO_FORMAT_PCM_24_BIT_PACKED\
    sampling_rates 96000\
    bit_width 24\
    app_type 69940\
  }\
  deep_buffer_24bit {\
    flags AUDIO_OUTPUT_FLAG_DEEP_BUFFER\
    formats AUDIO_FORMAT_PCM_24_BIT_PACKED\
    sampling_rates 96000\
    bit_width 24\
    app_type 69940\
  }\
  proaudio {\
    flags AUDIO_OUTPUT_FLAG_FAST\
    formats AUDIO_FORMAT_PCM_FLOAT\
    sampling_rates 96000\
    bit_width 32\
    app_type 69943\
  }' $APIOCXM
	sed -i '/^ *#/d; /^ *$/d' $APIOCXM
	done

  for OA2DPXML in ${A2DPXML}; do
	A2DPXM="$MODPATH$(echo $OA2DPXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100"/samplingRates="96000"/g' $A2DPXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
AI2ST' $A2DPXM
	sed -i '/AI2ST/,+1d' $A2DPXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
           <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $A2DPXM
	sed -i '/^ *#/d; /^ *$/d' $A2DPXM
	done

  for OBTQTIXML in ${BTQTIXML}; do
	BTQTIXM="$MODPATH$(echo $OBTQTIXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100"/samplingRates="96000"/g' $BTQTIXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
AI2ST' $BTQTIXM
	sed -i '/AI2ST/,+1d' $BTQTIXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
           <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $BTQTIXM
	sed -i '/^ *#/d; /^ *$/d' $BTQTIXM
	done

  for OUSBXML in ${USBXML}; do
	USBXM="$MODPATH$(echo $OUSBXML| sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $USBXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
AI2ST' $USBXM
	sed -i '/AI2ST/,+1d' $USBXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $USBXM
	sed -i '/name="usb_accessory output" role="source"/a\
AI2ST' $USBXM
	sed -i '/AI2ST/,+1d' $USBXM
	sed -i '/name="usb_accessory output" role="source"/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $USBXM
	sed -i '/^ *#/d; /^ *$/d' $USBXM
	done

else

	prop_process $MODPATH/common/24.prop

ui_print "*     ->[Fixing 24 bit 48 kHz Audio Output]<-     *"
ui_print "***************************************************"

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO,AUDIO_CHANNEL_OUT_MONO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_STEREO AUDIO_CHANNEL_OUT_MONO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_MONO,AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/channelMasks="AUDIO_CHANNEL_OUT_MONO AUDIO_CHANNEL_OUT_STEREO"/a\
\
\
\
\
' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LHDC/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LHDC/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LDAC"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LDAC"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LC3"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_LC3"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_FORCE_AOSP"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="AUDIO_FORMAT_FORCE_AOSP"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $APCXM
	sed -i '/encodedFormats="ldac_a2dp"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/encodedFormats="ldac_a2dp"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $APCXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/name="usb_accessory output" role="source"/a\
AI2ST' $APCXM
	sed -i '/AI2ST/,+1d' $APCXM
	sed -i '/name="usb_accessory output" role="source"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_DEEP_BUFFER/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"\
                             samplingRates="48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i '/AUDIO_OUTPUT_FLAG_VIRTUAL_DEEP_BUFFER/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"\
                             samplingRates="48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>\
#AIST' $APCXM
	sed -i '/AIST/,+3d' $APCXM
	sed -i '/^ *#/d; /^ *$/d' $APCXM
	done

  for OAPIOCXM in ${APIOCXML}; do
	APIOCXM="$MODPATH$(echo $OAPIOCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/deep_buffer_24/,+6d' $APIOCXM
	sed -i '/^outputs/a\
  deep_buffer_24 {\
    flags AUDIO_OUTPUT_FLAG_DEEP_BUFFER\
    formats AUDIO_FORMAT_PCM_24_BIT_PACKED\
    sampling_rates 48000\
    bit_width 24\
    app_type 69940\
  }\
  deep_buffer_24bit {\
    flags AUDIO_OUTPUT_FLAG_DEEP_BUFFER\
    formats AUDIO_FORMAT_PCM_24_BIT_PACKED\
    sampling_rates 48000\
    bit_width 24\
    app_type 69940\
  }' $APIOCXM
	sed -i '/^ *#/d; /^ *$/d' $APIOCXM
	done

  for OA2DPXML in ${A2DPXML}; do
	A2DPXM="$MODPATH$(echo $OA2DPXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100"/samplingRates="48000"/g' $A2DPXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
AI2ST' $A2DPXM
	sed -i '/AI2ST/,+1d' $A2DPXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
           <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $A2DPXM
	sed -i '/^ *#/d; /^ *$/d' $A2DPXM
	done

  for OBTQTIXML in ${BTQTIXML}; do
	BTQTIXM="$MODPATH$(echo $OBTQTIXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100"/samplingRates="48000"/g' $BTQTIXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
AI2ST' $BTQTIXM
	sed -i '/AI2ST/,+1d' $BTQTIXM
	sed -i '/AUDIO_DEVICE_OUT_BLUETOOTH_A2DP/a\
           <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"' $BTQTIXM
	sed -i '/^ *#/d; /^ *$/d' $BTQTIXM
	done

  for OUSBXML in ${USBXML}; do
	USBXM="$MODPATH$(echo $OUSBXML| sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/samplingRates="44100" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $USBXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
AI2ST' $USBXM
	sed -i '/AI2ST/,+1d' $USBXM
	sed -i '/AUDIO_DEVICE_OUT_USB_ACCESSORY/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $USBXM
	sed -i '/name="usb_accessory output" role="source"/a\
AI2ST' $USBXM
	sed -i '/AI2ST/,+1d' $USBXM
	sed -i '/name="usb_accessory output" role="source"/a\
           <profile name="" format="AUDIO_FORMAT_PCM_FLOAT"' $USBXM
	sed -i '/^ *#/d; /^ *$/d' $USBXM
	done

fi
fi
fi

	if [ "$SD888" ] || [ "$SM6375" ] || [ "$SM8450" ] || [ "$SM8550" ]; then
	prop_process $MODPATH/common/HIRES.prop
	fi


ui_print "***************************************************"
ui_print "*             [Install Other Tweaks]              *"
ui_print "***************************************************"
ui_print "*                 !!!Attention!!!                 *"
ui_print "*     These Tweaks are NOT Related To SOUND!!!    *"
ui_print "*                I added for myself               *"
ui_print "*            suitable for all devices             *"
ui_print "*  Includes Camera, Modem, Display, System & Etc  *"
ui_print "***************************************************"
ui_print "*             [Install Other Tweaks?]             *"
ui_print "***************************************************"
ui_print "* [Vol Up = YES          |         Vol Down = NO] *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "*          ->[Installing Other Tweaks]<-          *"
ui_print "***************************************************"

  for OQCVIRT in ${QCVIRTJ}; do
	QCVIRT="$MODPATH$(echo $OQCVIRT | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/"enable"        : true/"enable"        : false/g' $QCVIRT
	done

  for OATRACE in ${ATRACE}; do
	ATRAC="$MODPATH$(echo $OATRACE | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/debug.atrace.tags.enableflags/d' $ATRAC
	sed -i '/^ *#/d; /^ *$/d' $ATRAC
	done

  for ODEVF in ${DEVF}; do
	AODEVF="$MODPATH$(echo $ODEVF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/name="is_xiaomi">false</name="is_xiaomi">true</g' $AODEVF
	sed -i 's/name="is_xiaomi_device">false</name="is_xiaomi_device">true</g' $AODEVF
	sed -i 's/name="support_my_device">false</name="support_my_device">true</g' $AODEVF
	sed -i 's/name="support_erase_external_storage">false</name="support_erase_external_storage">true</g' $AODEVF
	sed -i 's/name="support_touchfeature_gamemode">false</name="support_touchfeature_gamemode">true</g' $AODEVF
#	sed -i 's/name="support_touch_sensitive">false</name="support_touch_sensitive">true</g' $AODEVF
	sed -i 's/name="support_force_touch">false</name="support_force_touch">true</g' $AODEVF
	sed -i 's/name="support_hide_discoverable">true</name="support_hide_discoverable">false</g' $AODEVF
	sed -i 's/name="support_agps">false</name="support_agps">true</g' $AODEVF
	sed -i 's/name="support_agps_paras">false</name="support_agps_paras">true</g' $AODEVF
	sed -i 's/name="support_agps_roaming">false</name="support_agps_roaming">true</g' $AODEVF
	sed -i 's/name="support_wifi_low_latency_mode">false</name="support_wifi_low_latency_mode">true</g' $AODEVF
	sed -i 's/name="support_network_rps_mode">false</name="support_network_rps_mode">true</g' $AODEVF
	sed -i 's/name="support_camera_peaking_mf">false</name="support_camera_peaking_mf">true</g' $AODEVF
	sed -i 's/name="support_camera_4k_quality">false</name="support_camera_4k_quality">true</g' $AODEVF
	sed -i 's/name="support_camera_8k_quality">false</name="support_camera_8k_quality">true</g' $AODEVF
	sed -i 's/name="support_zoom_mfnr">false</name="support_zoom_mfnr">true</g' $AODEVF
	sed -i 's/name="support_mfnr">false</name="support_mfnr">true</g' $AODEVF
	sed -i 's/name="support_camera_mfnr">false</name="support_camera_mfnr">true</g' $AODEVF
	sed -i 's/name="support_front_beauty_mfnr">false</name="support_front_beauty_mfnr">true</g' $AODEVF
	sed -i 's/name="support_video_hfr_mode">false</name="support_video_hfr_mode">true</g' $AODEVF
	sed -i 's/name="support_chroma_flash">false</name="support_chroma_flash">true</g' $AODEVF
	sed -i 's/name="support_object_track">false</name="support_object_track">true</g' $AODEVF
	sed -i 's/name="is_camera_hide_hht_menu">true</name="is_camera_hide_hht_menu">false</g' $AODEVF
	sed -i 's/name="is_camera_replace_higher_cost_effect">true</name="is_camera_replace_higher_cost_effect">false</g' $AODEVF
	sed -i 's/name="camera_adjust_picture_size_enabled">true</name="camera_adjust_picture_size_enabled">false</g' $AODEVF
	sed -i 's/name="support_display_expert_mode">false</name="support_display_expert_mode">true</g' $AODEVF
	sed -i 's/name="support_screen_enhance_engine">false</name="support_screen_enhance_engine">true</g' $AODEVF
	sed -i 's/name="support_true_color">false</name="support_true_color">true</g' $AODEVF
	sed -i 's/name="support_videobox_display_effect">false</name="support_videobox_display_effect">true</g' $AODEVF
	sed -i 's/name="is_support_video_tool_box">false</name="is_support_video_tool_box">true</g' $AODEVF
	sed -i 's/name="support_displayfeature_gamemode">false</name="support_displayfeature_gamemode">true</g' $AODEVF
	sed -i 's/name="support_secret_dc_backlight">false</name="support_secret_dc_backlight">true</g' $AODEVF
	sed -i 's/name="hide_flicker_backlight">true</name="hide_flicker_backlight">false</g' $AODEVF
	sed -i 's/name="support_AI_display">false</name="support_AI_display">true</g' $AODEVF
	sed -i 's/name="support_truetone">false</name="support_truetone">true</g' $AODEVF
	sed -i 's/name="support_power_mode">false</name="support_power_mode">true</g' $AODEVF
	sed -i 's/name="support_gallery_hdr">false</name="support_gallery_hdr">true</g' $AODEVF
	sed -i 's/name="support_hdr_enhance">false</name="support_hdr_enhance">true</g' $AODEVF
	sed -i 's/name="gallery_support_media_feature">false</name="gallery_support_media_feature">true</g' $AODEVF
	sed -i 's/name="gallery_support_video_compress">false</name="gallery_support_video_compress">true</g' $AODEVF
	sed -i 's/name="gallery_support_analytic_face_and_scene">false</name="gallery_support_analytic_face_and_scene">true</g' $AODEVF
	sed -i 's/name="gallery_support_time_burst_video">false</name="gallery_support_time_burst_video">true</g' $AODEVF
	sed -i 's/name="support_local_ocr">false</name="support_local_ocr">true</g' $AODEVF
	sed -i 's/name="gallery_support_dolby">false</name="gallery_support_dolby">true</g' $AODEVF
	sed -i 's/name="optimize_wakelock_enabled">false</name="optimize_wakelock_enabled">true</g' $AODEVF
	sed -i 's/name="support_google_rsa_protocol">false</name="support_google_rsa_protocol">true</g' $AODEVF
	sed -i 's/name="support_super_resolution">false</name="support_super_resolution">true</g' $AODEVF
	sed -i 's/name="support_ultra_resolution">false</name="support_ultra_resolution">true</g' $AODEVF
	sed -i 's/name="is_full_size_effect">false</name="is_full_size_effect">true</g' $AODEVF
	sed -i 's/name="support_full_size_panorama">false</name="support_full_size_panorama">true</g' $AODEVF
	sed -i 's/name="is_lower_size_effect">true</name="is_lower_size_effect">false</g' $AODEVF
	sed -i 's/name="is_lower_size_panorama">true</name="is_lower_size_panorama">false</g' $AODEVF
	sed -i '/<features>/a\
	<bool name="support_AI_display">true</bool>\
	<bool name="support_screen_enhance_engine">true</bool>\
	<bool name="support_zoom_mfnr">true</bool>\
	<bool name="support_mfnr">true</bool>\
	<bool name="support_camera_mfnr">true</bool>\
	<bool name="support_camera_4k_quality">true</bool>\
	<bool name="support_camera_8k_quality">true</bool>\
	<bool name="support_gallery_hdr">true</bool>\
	<bool name="support_hdr_enhance">true</bool>\
	<bool name="gallery_support_media_feature">true</bool>\
	<bool name="gallery_support_video_compress">true</bool>\
	<bool name="gallery_support_analytic_face_and_scene">true</bool>\
	<bool name="gallery_support_time_burst_video">true</bool>\
	<bool name="support_local_ocr">true</bool>\
	<bool name="gallery_support_dolby">true</bool>\
	<bool name="optimize_wakelock_enabled">true</bool>\
	<bool name="support_google_rsa_protocol">true</bool>\
	<bool name="support_super_resolution">true</bool>\
	<bool name="support_ultra_resolution">true</bool>\
	<bool name="is_full_size_effect">true</bool>\
	<bool name="is_lower_size_effect">false</bool>\
	<bool name="support_full_size_panorama">true</bool>\
	<bool name="is_lower_size_panorama">false</bool>\
	<bool name="is_camera_hide_hht_menu">false</bool>' $AODEVF
	sed -i '/^ *#/d; /^ *$/d' $AODEVF
	done

	settings put global dropbox_max_files 1
	settings put global ntp_server time.xtracloud.net
	settings put system lab_options_visible 1
	settings put system oneplus_lab_feature_key 1
	settings put system miui_recents_show_recommend 0

	prop_process $MODPATH/common/other.prop
fi

ui_print "***************************************************"
ui_print "*          ->[Installing Main Patches]<-          *"
ui_print "***************************************************"
ui_print "*         General Changes For All Devices         *"
ui_print "*          Includes Main Sound Parametrs          *"
ui_print "***************************************************"
ui_print "*      Installation time of this item ≈5 min      *"
ui_print "*                 Please, wait...                 *"
ui_print "***************************************************"
ui_print "***************************************************"
ui_print " "

  for OMIX in ${MPATHS}; do
	MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/COMP Switch" value="1"/COMP Switch" value="0"/g' $MIX
	sed -i 's/COMP0 Switch" value="1"/COMP0 Switch" value="0"/g' $MIX
	sed -i 's/COMP1 Switch" value="1"/COMP1 Switch" value="0"/g' $MIX
	sed -i 's/COMP2 Switch" value="1"/COMP2 Switch" value="0"/g' $MIX
	sed -i 's/COMP3 Switch" value="1"/COMP3 Switch" value="0"/g' $MIX
	sed -i 's/COMP4 Switch" value="1"/COMP4 Switch" value="0"/g' $MIX
	sed -i 's/COMP5 Switch" value="1"/COMP5 Switch" value="0"/g' $MIX
	sed -i 's/COMP6 Switch" value="1"/COMP6 Switch" value="0"/g' $MIX
	sed -i 's/COMP7 Switch" value="1"/COMP7 Switch" value="0"/g' $MIX
	sed -i 's/COMP8 Switch" value="1"/COMP8 Switch" value="0"/g' $MIX
	sed -i 's/Softclip0 Enable" value="1"/Softclip0 Enable" value="0"/g' $MIX
	sed -i 's/Softclip1 Enable" value="1"/Softclip1 Enable" value="0"/g' $MIX
	sed -i 's/Softclip2 Enable" value="1"/Softclip2 Enable" value="0"/g' $MIX
	sed -i 's/Softclip3 Enable" value="1"/Softclip3 Enable" value="0"/g' $MIX
	sed -i 's/Softclip4 Enable" value="1"/Softclip4 Enable" value="0"/g' $MIX
	sed -i 's/Softclip5 Enable" value="1"/Softclip5 Enable" value="0"/g' $MIX
	sed -i 's/Softclip6 Enable" value="1"/Softclip6 Enable" value="0"/g' $MIX
	sed -i 's/Softclip7 Enable" value="1"/Softclip7 Enable" value="0"/g' $MIX
	sed -i 's/Softclip8 Enable" value="1"/Softclip8 Enable" value="0"/g' $MIX
	sed -i 's/HPHL_RDAC Switch" value="0"/HPHL_RDAC Switch" value="1"/g' $MIX
	sed -i 's/HPHR_RDAC Switch" value="0"/HPHR_RDAC Switch" value="1"/g' $MIX
	sed -i 's/Boost Class-H Tracking Enable" value="0"/Boost Class-H Tracking Enable" value="1"/g' $MIX
	sed -i 's/DRE DRE Switch" value="0"/DRE DRE Switch" value="1"/g' $MIX
	sed -i 's/"RX INT0 DEM MUX" value="NORMAL_DSM_OUT"/"RX INT0 DEM MUX" value="CLSH_DSM_OUT"/g' $MIX
	sed -i 's/"RX INT1 DEM MUX" value="NORMAL_DSM_OUT"/"RX INT1 DEM MUX" value="CLSH_DSM_OUT"/g' $MIX
	sed -i 's/"RX INT2 DEM MUX" value="NORMAL_DSM_OUT"/"RX INT2 DEM MUX" value="CLSH_DSM_OUT"/g' $MIX
	sed -i 's/"RX INT3 DEM MUX" value="NORMAL_DSM_OUT"/"RX INT3 DEM MUX" value="CLSH_DSM_OUT"/g' $MIX
	sed -i 's/"RX INT4 DEM MUX" value="NORMAL_DSM_OUT"/"RX INT4 DEM MUX" value="CLSH_DSM_OUT"/g' $MIX
	sed -i '/EC Reference Channels/d' $APCXM
	sed -i '/EC Reference SampleRate/d' $APCXM
	sed -i '/EC Reference Bit Format/d' $APCXM
#	AIST_proc -u $MIX '/mixer/ctl[@name="DEC0 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="DEC1 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="DEC2 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="DEC3 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="DEC4 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="DEC5 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="DEC6 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="DEC7 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="DEC8 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="DEC9 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC0 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC1 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC2 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC3 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC4 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC5 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC6 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC7 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC8 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC9 Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX0 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX1 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX2 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX3 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX4 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX5 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX6 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX7 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX8 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX8 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX9 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX0 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX1 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX2 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX3 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX4 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX0 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX1 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX2 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX3 Digital Volume"]' "100"
#	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX4 Digital Volume"]' "100"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPHL Volume"]' "20"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPHR Volume"]' "20"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPHL"]' "Switch"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPHR"]' "Switch"
	AIST_proc -u $MIX '/mixer/ctl[@name="Load acoustic model"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="Voice Sidetone Enable"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="Audiosphere Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="Audiosphere Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="Set HPX OnOff"]' "0"
	AIST_proc -s $MIX '/mixer/ctl[@name="Set HPX OnOff"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="Set HPX ActiveBe"]' "0"
	AIST_proc -s $MIX '/mixer/ctl[@name="Set HPX ActiveBe"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="DS2 OnOff"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="DS2 OnOff"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="THD3 Compensation"]' "0"
	AIST_proc -s $MIX '/mixer/ctl[@name="THD3 Compensation"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="MSM ASphere Set Param"]' "0"
	AIST_proc -s $MIX '/mixer/ctl[@name="MSM ASphere Set Param"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="Codec Wideband"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="Codec Wideband"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="Set Custom Stereo OnOff"]' "0"
	AIST_proc -s $MIX '/mixer/ctl[@name="Set Custom Stereo OnOff"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="HiFi Function"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="HiFi Function"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="Virtual Bass Boost"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="Virtual Bass Boost"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="WSA_RX0 EC_HQ Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="WSA_RX1 EC_HQ Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="WSA_RX3 EC_HQ Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="WSA_RX4 EC_HQ Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT1 SEC MIX HPHL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT2 SEC MIX HPHR Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT1 MIX3 DSD HPHL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT2 MIX3 DSD HPHR Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPH Idle Detect"]' "ON"
	AIST_proc -s $MIX '/mixer/ctl[@name="HPH Idle Detect"]' "ON"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM_7_RX Format"]' "S24_LE"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM_7_RX SampleRate"]' "KHZ_192"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM_7_RX Channels"]' "Two"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS_7_RX Format"]' "S24_LE"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS_7_RX SampleRate"]' "KHZ_192"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS_7_RX Channels"]' "Two"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM_7_RX Format"]' "S24_LE"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM_7_RX SampleRate"]' "KHZ_192"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM_7_RX Channels"]' "Two"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS_7_RX Format"]' "S24_LE"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS_7_RX SampleRate"]' "KHZ_192"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS_7_RX Channels"]' "Two"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM7_RX ADM Format"]' "S24_LE"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM7_RX ADM SampleRate"]' "KHZ_192"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM7_RX ADM Channels"]' "Two"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM Format"]' "S24_LE"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM SampleRate"]' "KHZ_192"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM Channels"]' "Two"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM7_RX ADM Format"]' "S24_LE"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM7_RX ADM SampleRate"]' "KHZ_192"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM7_RX ADM Channels"]' "Two"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM Format"]' "S24_LE"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM SampleRate"]' "KHZ_192"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM Channels"]' "Two"
	AIST_proc -u $MIX '/mixer/ctl[@name="AUX_HPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="AUX_HPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="A2DP_HPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="A2DP_HPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="BT_HPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="BT_HPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="HPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="AUX_LPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="AUX_LPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="A2DP_LPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="A2DP_LPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="BT_LPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="BT_LPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="LPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="LPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="AUX_BPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="AUX_BPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="A2DP_BPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="A2DP_BPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="BT_BPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="BT_BPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="BPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="BPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="LDOH Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="LDOH Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="ST Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="ST Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="BDE Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="BDE Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="Amp DSP Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="Amp DSP Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="DRE En"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="DRE En"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_FIR Filter"]' "OFF"
	AIST_proc -s $MIX '/mixer/ctl[@name="RX_FIR Filter"]' "OFF"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-hifi-filter"]/ctl[@name="RX_FIR Filter"]' "OFF"
	AIST_proc -s $MIX '/mixer/path[@name="headphones-hifi-filter"]/ctl[@name="RX_FIR Filter"]' "OFF"
	AIST_proc -s $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="ADC0 Volume"]' "20"
	AIST_proc -s $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="ADC1 Volume"]' "20"
	AIST_proc -s $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="ADC2 Volume"]' "20"
	AIST_proc -s $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="ADC3 Volume"]' "20"
	AIST_proc -s $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="ADC4 Volume"]' "20"
	sed -i '/^ *#/d; /^ *$/d' $MIX
	done

  for OACONF in ${ACONFS}; do
	ACONF="$MODPATH$(echo $OACONF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	AIST_proc -u $ACONF '/configs/property[@name="audio.deep_buffer.media"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="audio.offload.disable"]' "false"
	AIST_proc -u $ACONF '/configs/property[@name="av.offload.enable"]' "false"
	AIST_proc -u $ACONF '/configs/property[@name="audio.offload.video"]' "false"
	AIST_proc -u $ACONF '/configs/property[@name="audio.offload.disable"]' "false"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.av.streaming.offload.enable"]' "false"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.offload.multiple.enabled"]' "false"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.offload.track.enable"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.voice.path.for.pcm.voip"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.use.sw.alac.decoder"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.use.sw.ape.decoder"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.use.sw.mpegh.decoder"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.flac.sw.decoder.24bit"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.hw.aac.encoder"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="compress_capture_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="compress_in_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="fm_power_opt"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="aac_adts_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="alac_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="ape_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="flac_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="pcm_offload_enabled_16"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="pcm_offload_enabled_24"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="qti_flac_decoder"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="vorbis_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="wma_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="a2dp_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="audio_zoom_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="audiosphere_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="custom_stereo_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="battery_listener_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="compress_metadata_needed"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="concurrent_capture_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="dsm_feedback_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="ext_hw_plugin_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="ext_qdsp_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="ext_spkr_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="ext_spkr_tfa_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="hfp_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="hifi_audio_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="hwdep_cal_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="keep_alive_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="kpi_optimize_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="maxx_audio_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="spkr_prot_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="usb_offload_burst_mode"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="usb_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="usb_offload_sidetone_vol_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="use_deep_buffer_as_primary_output"]' "false"
#	if [ "$SD662" ] || [ "$SD665" ] || [ "$SD670" ] || [ "$SD710" ] || [ "$SD720G" ] || [ "$SD730G" ] || [ "$SD765G" ] || [ "$SD820" ] || [ "$SD835" ] || [ "$SD845" ] || [ "$SD855" ] || [ "$SD865" ] || [ "$SD888" ] || [ "$SM6375" ] || [ "$SM8450" ] || [ "$SM8550" ]; then
#	AIST_proc -u $ACONF '/configs/flag[@name="compress_in_enabled"]' "false"
#	fi
	sed -i '/^ *#/d; /^ *$/d' $ACONF
	done

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/flags="AUDIO_OUTPUT_FLAG_FAST|AUDIO_OUTPUT_FLAG_RAW/flags="AUDIO_OUTPUT_FLAG_FAST/g' $APCXM
	sed -i 's/flags="AUDIO_OUTPUT_FLAG_RAW|AUDIO_OUTPUT_FLAG_FAST/flags="AUDIO_OUTPUT_FLAG_FAST/g' $APCXM
	sed -i 's/flags="AUDIO_OUTPUT_FLAG_FAST AUDIO_OUTPUT_FLAG_RAW/flags="AUDIO_OUTPUT_FLAG_FAST/g' $APCXM
	sed -i 's/flags="AUDIO_OUTPUT_FLAG_RAW AUDIO_OUTPUT_FLAG_FAST/flags="AUDIO_OUTPUT_FLAG_FAST/g' $APCXM
	sed -i '/^ *#/d; /^ *$/d' $APCXM
	done


	cp_ch $MODPATH/system/vendor/etc/bluetooth_qti_audio_policy_configuration.xml $MODPATH/system/vendor/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml
	rm -rf $MODPATH/tools/*
	rm -rf /data/system/package_cache/*/*
	rm -rf /data/resource-cache/*
	rm -rf /cache/*
	find $MODPATH -empty -type d -delete
