
AIST_proc() {
  local Name0=$(echo "$3" | sed -r "s|^.*/.*\[@(.*)=\".*\".*$|\1|")
  local Value0=$(echo "$3" | sed -r "s|^.*/.*\[@.*=\"(.*)\".*$|\1|")
  [ "$(echo "$4" | grep '=')" ] && Name1=$(echo "$4" | sed "s|=.*||") || local Name1="value"
  local Value1=$(echo "$4" | sed "s|.*=||")
  case $1 in
  "-s"|"-u"|"-i")
    local SNP=$(echo "$3" | sed -r "s|(^.*/.*)\[@.*=\".*\".*$|\1|")
    local NP=$(dirname "$SNP")
    local SN=$(basename "$SNP")
	if [ "$5" ]; then
      [ "$(echo "$5" | grep '=')" ] && local Name2=$(echo "$5" | sed "s|=.*||") || local Name2="value"
      local Value2=$(echo "$5" | sed "s|.*=||")
	fi
	if [ "$6" ]; then
      [ "$(echo "$6" | grep '=')" ] && local Name3=$(echo "$6" | sed "s|=.*||") || local Name3="value"
      local Value3=$(echo "$6" | sed "s|.*=||")
	fi
	if [ "$7" ]; then
      [ "$(echo "$7" | grep '=')" ] && local Name4=$(echo "$7" | sed "s|=.*||") || local Name4="value"
      local Value4=$(echo "$7" | sed "s|.*=||")
	fi
  ;;
  esac
  case "$1" in
    "-d") xmlstarlet ed -L -d "$3" "$2";;
    "-u") xmlstarlet ed -L -u "$3/@$Name1" -v "$Value1" "$2";;
    "-s")
  	if [ "$(xmlstarlet sel -t -m "$3" -c . "$2")" ]; then
        xmlstarlet ed -L -u "$3/@$Name1" -v "$Value1" "$2"
      else
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -r "$SNP-$MODID" -v "$SN" "$2"
  	fi;;
    "-i")
  	if [ "$(xmlstarlet sel -t -m "$3[@$Name1=\"$Value1\"]" -c . "$2")" ]; then
        xmlstarlet ed -L -d "$3[@$Name1=\"$Value1\"]" "$2"
  	fi
  	if [ -z "$Value3" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -r "$SNP-$MODID" -v "$SN" "$2"
      elif [ "$Value4" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -i "$SNP-$MODID" -t attr -n "$Name3" -v "$Value3" \
        -i "$SNP-$MODID" -t attr -n "$Name4" -v "$Value4" \
        -r "$SNP-$MODID" -v "$SN" "$2"
      elif [ "$Value3" ]; then
        xmlstarlet ed -L -s "$NP" -t elem -n "$SN-$MODID" \
        -i "$SNP-$MODID" -t attr -n "$Name0" -v "$Value0" \
        -i "$SNP-$MODID" -t attr -n "$Name1" -v "$Value1" \
        -i "$SNP-$MODID" -t attr -n "$Name2" -v "$Value2" \
        -i "$SNP-$MODID" -t attr -n "$Name3" -v "$Value3" \
        -r "$SNP-$MODID" -v "$SN" "$2"
  	fi
      ;;
  esac
}

[ -f /system/vendor/build.prop ] && BUILDS="/system/build.prop /system/vendor/build.prop" || BUILDS="/system/build.prop"
SD617=$(grep "ro.board.platform=msm8952" $BUILDS)
SD625=$(grep "ro.board.platform=msm8953" $BUILDS)
SD660=$(grep "ro.board.platform=sdm660" $BUILDS)
SD662=$(grep "ro.board.platform=bengal" $BUILDS)
SD665=$(grep "ro.board.platform=trinket" $BUILDS)
SD670=$(grep "ro.board.platform=sdm670" $BUILDS)
SD710=$(grep "ro.board.platform=sdm710" $BUILDS)
SD720G=$(grep "ro.board.platform=atoll" $BUILDS)
SD730G=$(grep "ro.board.platform=sm6150" $BUILDS)
SD765G=$(grep "ro.board.platform=lito" $BUILDS)
SD820=$(grep "ro.board.platform=msm8996" $BUILDS)
SD835=$(grep "ro.board.platform=msm8998" $BUILDS)
SD845=$(grep "ro.board.platform=sdm845" $BUILDS)
SD855=$(grep "ro.board.platform=msmnile" $BUILDS)
SD865=$(grep "ro.board.platform=kona" $BUILDS)
SD888=$(grep "ro.board.platform=lahaina" $BUILDS)
SM8450=$(grep "ro.board.platform=taro" $BUILDS)

if [ "$SD662" ] || [ "$SD665" ] || [ "$SD670" ] || [ "$SD710" ] || [ "$SD720G" ] || [ "$SD730G" ] || [ "$SD765G" ] || [ "$SD820" ] || [ "$SD835" ] || [ "$SD845" ] || [ "$SD855" ] || [ "$SD865" ] || [ "$SD888" ] || [ "$SM8450" ]; then
  HIFI=true
ui_print " "
ui_print "- Device with support Hi-Res detected! -"
else
  NOHIFI=false
ui_print " "
ui_print " - Device without support Hi-Res detected! -"
fi

RN5PRO=$(grep -E "ro.product.vendor.device=whyred.*" $BUILDS)
RN6PRO=$(grep -E "ro.product.vendor.device=tulip.*" $BUILDS)
RN7=$(grep -E "ro.product.vendor.device=lavender.*" $BUILDS)
RN7PRO=$(grep -E "ro.product.vendor.device=violet.*" $BUILDS)
MI9=$(grep -E "ro.product.vendor.device=cepheus.*" $BUILDS)
MI10=$(grep -E "ro.product.vendor.device=umi.*" $BUILDS)
K20P=$(grep -E "ro.product.vendor.device=raphael.*|ro.product.vendor.device=raphaelin.*|ro.product.vendor.device=raphaels.*" $BUILDS)
MI8=$(grep -E "ro.product.vendor.device=dipper.*" $BUILDS)
MI8P=$(grep -E "ro.product.vendor.device=equuleus.*" $BUILDS)
MI9P=$(grep -E "ro.product.vendor.device=crux.*" $BUILDS)
POCOF1=$(grep -E "ro.product.vendor.device=beryllium.*" $BUILDS)
POCOF2P=$(grep -E "ro.product.vendor.device=lmi.*" $BUILDS)
MPATHS="$(find /system /vendor /system_ext /product /odm -type f -name "*mixer_paths*.xml")"
APINF="$(find /system /vendor /system_ext /product /odm -type f -name "audio_platform_info*.xml")"
ACONFS="$(find /system /vendor /system_ext /product /odm -type f -name "audio_configs*.xml")"
APCXML="$(find /system /vendor /system_ext /product /odm -type f -name "*policy_configuration*.xml")"
APIOCXML="$(find /system /vendor /system_ext /product /odm -type f -name "audio_io_policy.conf")"
DEVF="$(find /system/etc/device_features /vendor/etc/device_features /system_ext/etc/device_features /product/etc/device_features /odm/etc/device_features -type f -name "*.xml")"
BTCONF="$(find /system /vendor /system_ext /product /odm -type f -name "bt_configstore.conf")"
BTCONF2="$(find /system /vendor /system_ext /product /odm -type f -name "bt_stack.conf")"
DAXXML="$(find /system/etc/dolby /vendor/etc/dolby /system_ext/etc/dolby /product/etc/dolby /odm/etc/dolby -type f -name "*.xml")"
LOG=$MODPATH/common/other

mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/

  for OMIX in ${MPATHS}; do
	MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	cp_ch $ORIGDIR$OMIX $MIX
	sed -i 's/\t/  /g' $MIX
	done

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	cp_ch $ORIGDIR$OAPCXM $APCXM
	sed -i 's/\t/  /g' $APCXM
	done

  for ODEVF in ${DEVF}; do
	AODEVF="$MODPATH$(echo $ODEVF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	cp_ch $ORIGDIR$ODEVF $AODEVF
	sed -i 's/\t/  /g' $AODEVF
	done

  for OAPIOCXM in ${APIOCXML}; do
	APIOCXM="$MODPATH$(echo $OAPIOCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	cp_ch $ORIGDIR$OAPIOCXM $APIOCXM
	sed -i 's/\t/  /g' $APIOCXM
	done

ui_print " "
ui_print " - Boost Sound Volume Levels -"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "*     This item boosting sound volume levels!     *"
  ui_print "*       Be careful when listening to music        *"
  ui_print "*               at maximum volume!                *"
  ui_print "*                                                 *"
  ui_print "*       Actual for devices with quiet sound       *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "*      Installation time of this item ≈1 min      *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Boost Sound Volume Levels?"
ui_print " "

sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " "

if $VKSEL; then

ui_print " - Boosting Sound Volume Levels -"
ui_print " -        Please, wait...       -"

  for OMIX in ${MPATHS}; do
	MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	if ! $NOHIFI; then
	AIST_proc -u $MIX '/mixer/ctl[@name="RX0 Digital Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX4 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX5 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX6 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX7 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX8 Digital Volume"]' "90"
	AIST_proc -s $MIX '/mixer/ctl[@name="RX8 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX3 Digital Volume"]' "90"
	AIST_proc -s $MIX '/mixer/ctl[@name="WSA_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX3 Digital Volume"]' "90"
	AIST_proc -s $MIX '/mixer/ctl[@name="RX_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX4 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX5 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX6 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX7 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX8 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="LINEOUT1 Volume"]' "16"
	AIST_proc -u $MIX '/mixer/ctl[@name="LINEOUT2 Volume"]' "16"
	elif $HIFI; then
	AIST_proc -u $MIX '/mixer/ctl[@name="RX0 Digital Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX4 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX5 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX6 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX7 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX8 Digital Volume"]' "90"
	AIST_proc -s $MIX '/mixer/ctl[@name="RX8 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_RX3 Digital Volume"]' "90"
	AIST_proc -s $MIX '/mixer/ctl[@name="WSA_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_RX3 Digital Volume"]' "90"
	AIST_proc -s $MIX '/mixer/ctl[@name="RX_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX4 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX5 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX6 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX7 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX8 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX4 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX5 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX6 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX7 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX8 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="WSA_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="WSA_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="WSA_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="WSA_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX4 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX5 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX6 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX7 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX8 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="WSA_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="WSA_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="WSA_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="WSA_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX4 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX5 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX6 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX7 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX8 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="WSA_RX0 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="WSA_RX1 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="WSA_RX2 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="WSA_RX3 Digital Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="LINEOUT1 Volume"]' "16"
	AIST_proc -u $MIX '/mixer/ctl[@name="LINEOUT2 Volume"]' "16"
	fi
	done
fi

ui_print " "
ui_print " - Boost Microphones Volume Levels -"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "*  This item boosting microphones volume levels!  *"
  ui_print "*                                                 *"
  ui_print "*    Actual for devices with quiet microphones    *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "*      Installation time of this item ≈1 min      *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Boost Microphones Volume Levels?"
ui_print " "

sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " "

if $VKSEL; then

ui_print " - Boosting Microphones Volume Levels -"
ui_print " -           Please, wait...          -"

  for OMIX in ${MPATHS}; do
	MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	if ! $NOHIFI; then
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC0 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC1 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC2 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC3 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC4 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC5 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC6 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC7 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC8 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC0 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC1 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC2 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC3 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC4 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC5 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC6 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC7 Volume"]' "94"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC8 Volume"]' "94"
	elif $HIFI; then
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC0 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC1 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC2 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC3 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC4 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC5 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC6 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC7 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="DEC8 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC0 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC1 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC2 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC3 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC4 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC5 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC6 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC7 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="TX_DEC8 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="VA_DEC0 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="VA_DEC1 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="VA_DEC2 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="VA_DEC3 Volume"]' "90"
	AIST_proc -u $MIX '/mixer/ctl[@name="VA_DEC4 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="VA_DEC5 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="VA_DEC6 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="VA_DEC7 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/ctl[@name="VA_DEC8 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/path[@name="headset-mic"]/ctl[@name="TX_DEC0 Volume"]' "88"
	AIST_proc -u $MIX '/mixer/path[@name="voice-tty-full-headset-mic"]/ctl[@name="TX_DEC5 Volume"]' "88"
	fi
	done
fi

ui_print " "
ui_print " - Fixing 96kHz Sound -"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "* !Attention! Sound failure possible or bootloop! *"
  ui_print "*                                                 *"
  ui_print "*          Fixing 96kHz for Audio Output          *"
  ui_print "*                                                 *"
  ui_print "*If, when this item is set, the sound is distorted*"
  ui_print "*    or becomes flat, or does not sound at all    *"
  ui_print "*     Reinstalls the module without this item.    *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Fix 96kHz Sound?"
ui_print " "
sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " " 

if $VKSEL; then

ui_print " - Fixing 96kHz Sound -"

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i 's/samplingRates="44100,48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $APCXM
	sed -i 's/samplingRates="44100" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $APCXM
	sed -i 's/samplingRates="48000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/samplingRates="8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000" channelMasks="AUDIO_CHANNEL_OUT_STEREO"/g' $APCXM
	done

  for OAPIOCXM in ${APIOCXML}; do
	APIOCXM="$MODPATH$(echo $OAPIOCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i 's/sampling_rates 48000/sampling_rates 8000|11025|12000|16000|22050|24000|32000|44100,48000|64000|88200|96000/g' $APIOCXM
	sed -i 's/sampling_rates 44100|48000/sampling_rates 8000|11025|12000|16000|22050|24000|32000|44100,48000|64000|88200|96000/g' $APIOCXM
	done
fi

ui_print " "
ui_print " - Replacing 16 Bit With FLOAT Bit -"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "* !Attention! Sound failure possible or bootloop! *"
  ui_print "*                                                 *"
  ui_print "*         Replacing 16 Bit With FLOAT Bit         *"
  ui_print "*                                                 *"
  ui_print "*If, when this item is set, the sound is distorted*"
  ui_print "*    or becomes flat, or does not sound at all    *"
  ui_print "*     Reinstalls the module without this item.    *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Replace 16 Bit With FLOAT Bit?"
ui_print " "
sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " " 

if $VKSEL; then

ui_print " - Replacing 16 Bit With FLOAT Bit -"

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i 's/profile name="" format="AUDIO_FORMAT_PCM_16_BIT"/profile name="" format="AUDIO_FORMAT_PCM_FLOAT"/g' $APCXM
	done

  for OAPIOCXM in ${APIOCXML}; do
	APIOCXM="$MODPATH$(echo $OAPIOCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i 's/formats AUDIO_FORMAT_PCM_16_BIT/formats AUDIO_FORMAT_PCM_FLOAT/g' $APIOCXM
	done
fi

ui_print " "
ui_print " - Install Other Tweaks -"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "*                 !!!Attention!!!                 *"
  ui_print "*    Various tweaks not related to sound that     *"
  ui_print "*                I added for myself               *"
  ui_print "* Including Camera, Radio(Modem), Display, System *"
  ui_print "*                 and Other Tweaks                *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
ui_print "   Install Other Tweaks?"
ui_print " "
sleep 1
ui_print "   Vol Up = YES, Vol Down = NO"
ui_print " " 

if $VKSEL; then

ui_print " - Installing Other Tweaks -"

	prop_process $MODPATH/common/other.prop
	cp_ch $LOG/dummy $MODPATH/system/bin/cnss_diag
	cp_ch $LOG/dummy $MODPATH/system/vendor/bin/cnss_diag
	cp_ch $LOG/dummy $MODPATH/system/bin/tcpdump
	cp_ch $LOG/dummy $MODPATH/system/vendor/bin/tcpdump
	cp_ch $LOG/dummy $MODPATH/system/bin/logwrapper
	cp_ch $LOG/dummy $MODPATH/system/vendor/bin/logwrapper
	cp_ch $LOG/dummy $MODPATH/system/bin/qseelogd
	cp_ch $LOG/dummy $MODPATH/system/vendor/bin/qseelogd
	cp_ch $LOG/dummy $MODPATH/system/etc/init/init.qseelogd.rc
	cp_ch $LOG/dummy $MODPATH/system/vendor/etc/init/init.qseelogd.rc
	cp_ch $LOG/dummy $MODPATH/system/product/bin/qseelogd
	cp_ch $LOG/dummy $MODPATH/system/product/etc/init/init.qseelogd.rc
	cp_ch $LOG/dummy $MODPATH/system/bin/atrace
	cp_ch $LOG/dummy $MODPATH/system/vendor/bin/atrace
	cp_ch $LOG/dummy $MODPATH/system/etc/init/atrace.rc
	cp_ch $LOG/dummy $MODPATH/system/vendor/etc/init/atrace.rc
	cp_ch $LOG/Traceur.apk $MODPATH/system/app/Traceur/Traceur.apk
	cp_ch $LOG/Traceur.apk $MODPATH/system/vendor/app/Traceur/Traceur.apk
	cp_ch $LOG/Traceur.apk $MODPATH/system/priv-app/Traceur/Traceur.apk
	cp_ch $LOG/Traceur.apk $MODPATH/system/vendor/priv-app/Traceur/Traceur.apk
	cp_ch $LOG/dummy $MODPATH/system/bin/notify_traceur.sh
	cp_ch $LOG/dummy $MODPATH/system/vendor/bin/notify_traceur.sh
	cp_ch $LOG/dummy $MODPATH/system/etc/init/traceur.rc
	cp_ch $LOG/dummy $MODPATH/system/vendor/etc/init/traceur.rc

  for ODEVF in ${DEVF}; do
	AODEVF="$MODPATH$(echo $ODEVF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i 's/name="support_agps">false</name="support_agps">true</g' $AODEVF
	sed -i 's/name="is_xiaomi">false</name="is_xiaomi">true</g' $AODEVF
	sed -i 's/name="is_hongmi">false</name="is_hongmi">true</g' $AODEVF
	sed -i 's/name="is_redmi">false</name="is_redmi">true</g' $AODEVF
	sed -i 's/name="support_erase_external_storage">false</name="support_erase_external_storage">true</g' $AODEVF
	sed -i 's/name="support_agps_paras">false</name="support_agps_paras">true</g' $AODEVF
	sed -i 's/name="support_agps_roaming">false</name="support_agps_roaming">true</g' $AODEVF
	sed -i 's/name="support_camera_4k_quality">false</name="support_camera_4k_quality">true</g' $AODEVF
	sed -i 's/name="support_extreme_battery_saver">false</name="support_extreme_battery_saver">true</g' $AODEVF
	sed -i 's/name="support_display_expert_mode">false</name="support_display_expert_mode">true</g' $AODEVF
	sed -i 's/name="support_nature_mode">false</name="support_nature_mode">true</g' $AODEVF
	sed -i 's/name="support_blackshark_fast_connect">false</name="support_blackshark_fast_connect">true</g' $AODEVF
	sed -i 's/name="support_blackshark_right_fast_connect">false</name="support_blackshark_right_fast_connect">true</g' $AODEVF
	sed -i 's/name="support_wifi_low_latency_mode">false</name="support_wifi_low_latency_mode">true</g' $AODEVF
	sed -i 's/name="support_network_rps_mode">false</name="support_network_rps_mode">true</g' $AODEVF
	sed -i 's/name="support_power_mode">false</name="support_power_mode">true</g' $AODEVF
	sed -i 's/name="support_videobox_display_effect">false</name="support_videobox_display_effect">true</g' $AODEVF
	sed -i 's/name="is_support_video_tool_box">false</name="is_support_video_tool_box">true</g' $AODEVF
	sed -i 's/name="support_camera_peaking_mf">false</name="support_camera_peaking_mf">true</g' $AODEVF
	sed -i 's/name="support_displayfeature_gamemode">true</name="support_displayfeature_gamemode">false</g' $AODEVF
	sed -i 's/name="support_front_beauty_mfnr">true</name="support_front_beauty_mfnr">false</g' $AODEVF
	sed -i 's/name="camera_adjust_picture_size_enabled">true</name="camera_adjust_picture_size_enabled">false</g' $AODEVF
	sed -i 's/name="support_displayfeature_gamemode">true</name="support_displayfeature_gamemode">false</g' $AODEVF
	sed -i 's/name="support_zoom_mfnr">true</name="support_zoom_mfnr">false</g' $AODEVF
	sed -i 's/name="is_camera_hide_hht_menu">true</name="is_camera_hide_hht_menu">false</g' $AODEVF
	sed -i 's/name="support_page_layout">false</name="support_page_layout">true</g' $AODEVF
	sed -i 's/name="support_object_track">false</name="support_object_track">true</g' $AODEVF
	sed -i 's/name="enable_flash_global">false</name="enable_flash_global">true</g' $AODEVF
	sed -i 's/name="support_video_hfr_mode">false</name="support_video_hfr_mode">true</g' $AODEVF
	sed -i 's/name="support_ai_task">false</name="support_ai_task">true</g' $AODEVF
	sed -i 's/name="support_provision_app_permission">true</name="support_provision_app_permission">false</g' $AODEVF
	done
fi

ui_print " "
ui_print " - Installing Main Patches -"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "*          General changes for All devices.       *"
  ui_print "*  Including maximum sound quality, Bass Booster, *"
  ui_print "* Hi-Fi parametrs, Dolby Surround parametrs, etc. *"
  ui_print "*                                                 *"
  ui_print "***************************************************"
  ui_print "*                                                 *"
  ui_print "*    Installation time of this item ≈5-10 min     *"
  ui_print "*                 Please, wait...                 *"
  ui_print "*                                                 *"
  ui_print "***************************************************"

  for OMIX in ${MPATHS}; do
	MIX="$MODPATH$(echo $OMIX | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	if ! $NOHIFI; then
	AIST_proc -s $MIX '/mixer/ctl[@name="RX_HPH_PWR_MODE"]' "HIRES"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX HPH Mode"]' "HD2"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_HPH_PWR_MODE"]' "HIRES"
	AIST_proc -s $MIX '/mixer/ctl[@name="VBoost Ctrl"]' "AlwaysOn"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPHL"]' "Switch"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPHR"]' "Switch"
	AIST_proc -u $MIX '/mixer/ctl[@name="Load acoustic model"]' "1"
	elif $HIFI; then
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="top-speaker"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="bottom-speaker"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="hph-hifi-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -s $MIX '/mixer/path[@name="hph-hifi-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="hph-highquality-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -s $MIX '/mixer/path[@name="hph-highquality-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="hph-lowpower-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -s $MIX '/mixer/path[@name="hph-lowpower-mode"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="hph-class-ab-mode"]/ctl[@name="RX HPH Mode"]' "CLS_AB_HIFI"
	AIST_proc -s $MIX '/mixer/path[@name="hph-class-ab-mode"]/ctl[@name="RX HPH Mode"]' "CLS_AB_HIFI"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headset"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -s $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="RX HPH Mode"]' "CLS_H_LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="top-speaker"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="bottom-speaker"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="hph-hifi-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -s $MIX '/mixer/path[@name="hph-hifi-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="hph-highquality-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -s $MIX '/mixer/path[@name="hph-highquality-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="hph-lowpower-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -s $MIX '/mixer/path[@name="hph-lowpower-mode"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headset"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -s $MIX '/mixer/path[@name="voice-headset"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI" 
	AIST_proc -u $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	AIST_proc -s $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="RX_HPH_PWR_MODE"]' "LOHIFI"
	fi
	AIST_proc -u $MIX '/mixer/ctl[@name="Voice Sidetone Enable"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="MSM ASphere Set Param"]' "0"
	AIST_proc -s $MIX '/mixer/ctl[@name="MSM ASphere Set Param"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="Codec Wideband"]' "0"
	AIST_proc -s $MIX '/mixer/ctl[@name="Codec Wideband"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="Set Custom Stereo OnOff"]' "0"
	AIST_proc -s $MIX '/mixer/ctl[@name="Set Custom Stereo OnOff"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="HiFi Function"]' "On"
	AIST_proc -s $MIX '/mixer/ctl[@name="HiFi Function"]' "On"
	AIST_proc -u $MIX '/mixer/ctl[@name="Custom Filter"]' "ON"
	AIST_proc -s $MIX '/mixer/ctl[@name="Custom Filter"]' "ON"
	AIST_proc -u $MIX '/mixer/ctl[@name="Filter Shape"]' "Slow Rolloff"
	AIST_proc -s $MIX '/mixer/ctl[@name="Filter Shape"]' "Slow Rolloff"
	AIST_proc -u $MIX '/mixer/ctl[@name="EC Reference Channels"]' "Zero"
	AIST_proc -u $MIX '/mixer/ctl[@name="EC Reference Bit Format"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="EC Reference SampleRate"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="SpkrLeft BOOST Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SpkrRight BOOST Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SpkrLeft VISENSE Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SpkrRight VISENSE Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SpkrLeft SWR DAC_Port Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SpkrRight SWR DAC_Port Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="ANC OUT HPHL Enable Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="ANC OUT HPHR Enable Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="Virtual Bass Boost"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="Virtual Bass Boost"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="WSA_RX0 EC_HQ Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="WSA_RX1 EC_HQ Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="WSA_RX3 EC_HQ Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="WSA_RX4 EC_HQ Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT1 SEC MIX HPHL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT2 SEC MIX HPHR Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="RX INT3 SEC MIX LO1 Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="RX INT4 SEC MIX LO2 Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT1 MIX3 DSD HPHL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT2 MIX3 DSD HPHR Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT0 DEM MUX"]' "CLSH_DSM_OUT"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT1 DEM MUX"]' "CLSH_DSM_OUT"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT2 DEM MUX"]' "CLSH_DSM_OUT"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT3 DEM MUX"]' "CLSH_DSM_OUT"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX INT4 DEM MUX"]' "CLSH_DSM_OUT"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPH Idle Detect"]' "ON"
	AIST_proc -s $MIX '/mixer/ctl[@name="HPH Idle Detect"]' "ON"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPHL_RDAC Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPHR_RDAC Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="A2DP_SLIM7_UL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="PCM_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="USB_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM7_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="A2DP_SLIM7_UL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="PCM_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="USB_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM_7_RX Format"]' "S24_LE"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM_7_RX SampleRate"]' "KHZ_192"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM_7_RX Channels"]' "Two"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS_7_RX Format"]' "S24_LE"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS_7_RX SampleRate"]' "KHZ_192"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS_7_RX Channels"]' "Two"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM_7_RX Format"]' "S24_LE"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM_7_RX SampleRate"]' "KHZ_192"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM_7_RX Channels"]' "Two"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS_7_RX Format"]' "S24_LE"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS_7_RX SampleRate"]' "KHZ_192"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS_7_RX Channels"]' "Two"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM7_RX ADM Format"]' "S24_LE"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM7_RX ADM SampleRate"]' "KHZ_192"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM7_RX ADM Channels"]' "Two"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM Format"]' "S24_LE"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM SampleRate"]' "KHZ_192"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM Channels"]' "Two"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM7_RX ADM Format"]' "S24_LE"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM7_RX ADM SampleRate"]' "KHZ_192"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIM7_RX ADM Channels"]' "Two"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM Format"]' "S24_LE"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM SampleRate"]' "KHZ_192"
	AIST_proc -s $MIX '/mixer/ctl[@name="SLIMBUS7_RX ADM Channels"]' "Two"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIM7_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SCO_SLIM7_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="SCO_SLIM7_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="HFP_SLIM7_UL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="HFP_PRI_AUX_UL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="HFP_AUX_UL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="HFP_INT_UL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS0_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS1_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS2_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS3_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS4_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS5_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS6_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SLIMBUS7_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="INT0_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="INT1_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="INT2_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="INT3_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="INT4_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="PRI_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SEC_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="TERT_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="QUAT_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="QUIN_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="SEN_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_CDC_DMA_RX_0_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_CDC_DMA_RX_0_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_CDC_DMA_RX_1_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="RCV Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="TH Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="TL Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="BH Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="BL Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="echo-reference"]/ctl[@name="EC Reference Bit Format"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="echo-reference"]/ctl[@name="EC Reference SampleRate"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="echo-reference"]/ctl[@name="EC Reference Channels"]' "Zero"
	AIST_proc -u $MIX '/mixer/path[@name="echo-reference headset"]/ctl[@name="EC Reference Bit Format"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="echo-reference headset"]/ctl[@name="EC Reference SampleRate"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="echo-reference headset"]/ctl[@name="EC Reference Channels"]' "Zero"
	AIST_proc -u $MIX '/mixer/path[@name="echo-reference a2dp"]/ctl[@name="EC Reference Bit Format"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="echo-reference a2dp"]/ctl[@name="EC Reference SampleRate"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="echo-reference a2dp"]/ctl[@name="EC Reference Channels"]' "Zero"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-suspend"]/ctl[@name="Mi_Ultrasound Suspend"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-suspend"]/ctl[@name="Ultrasound Suspend"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS0_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS1_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS2_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS3_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS4_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS5_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS6_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS7_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="INT0_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="INT1_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="INT2_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="INT3_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="INT4_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="PRI_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SEC_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="TERT_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="QUAT_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="QUIN_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SEN_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="WSA_CDC_DMA_RX_0_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="WSA_CDC_DMA_RX_1_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="RX_CDC_DMA_RX_0_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="RX_CDC_DMA_RX_1_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="USB_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIM7_RX_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SCO_SLIM7_DL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="A2DP_SLIM7_UL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="HFP_SLIM7_UL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="HFP_PRI_AUX_UL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="HFP_AUX_UL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="HFP_INT_UL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS0_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS1_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS2_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS3_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS4_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS5_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS6_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIMBUS7_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="INT0_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="INT1_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="INT2_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="INT3_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="INT4_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="PRI_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SEC_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="TERT_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="QUAT_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="QUIN_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SEN_MI2S_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="WSA_CDC_DMA_RX_0_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="WSA_CDC_DMA_RX_1_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="RX_CDC_DMA_RX_0_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="RX_CDC_DMA_RX_1_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="USB_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SLIM7_RX_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="SCO_SLIM7_DL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="A2DP_SLIM7_UL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="HFP_SLIM7_UL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="HFP_PRI_AUX_UL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="HFP_AUX_UL_HL Switch"]' "1"
	AIST_proc -s $MIX '/mixer/path[@name="ultrasound-proximity-output"]/ctl[@name="HFP_INT_UL_HL Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-and-headphones"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="speaker-mono-2"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="handset"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="ultrasound-handset"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-and-haptics"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-44.1"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-dsd"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="anc-headphones"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="voice-headphones"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="COMP3 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="COMP4 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="COMP5 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="COMP6 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="COMP7 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="COMP8 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="SpkrLeft COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="SpkrRight COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="WSA_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="WSA_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="RX_COMP1 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="RX_COMP2 Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="HPHL_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/path[@name="tty-headphones"]/ctl[@name="HPHR_COMP Switch"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="AUX_HPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="AUX_HPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="A2DP_HPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="A2DP_HPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="BT_HPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="BT_HPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="HPF Enable"]' "Off"
	AIST_proc -s $MIX '/mixer/ctl[@name="HPF Enable"]' "Off"
	AIST_proc -u $MIX '/mixer/ctl[@name="LDOH Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="LDOH Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="LPI Enable"]' "0"
	AIST_proc -s $MIX '/mixer/ctl[@name="LPI Enable"]' "0"
	AIST_proc -u $MIX '/mixer/ctl[@name="ST Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="ST Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="BDE Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="BDE AMP Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="BDE Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="BDE AMP Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="Amp DSP Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="Amp DSP Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="DRE En"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="DRE En"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RCV DRE DRE Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="RCV DRE DRE Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="TH DRE DRE Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="TH DRE DRE Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="TL DRE DRE Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="TL DRE DRE Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="BH DRE DRE Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="BH DRE DRE Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="BL DRE DRE Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="BL DRE DRE Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RCV Boost Class-H Tracking Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="RCV Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RCV AMP Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="RCV AMP Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RCV AMP Enable Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="RCV AMP Enable Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="Boost Class-H Tracking Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="AMP Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="AMP Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="AMP Enable Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="AMP Enable Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="TH Boost Class-H Tracking Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="TH Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="TH AMP Enable Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="TH AMP Enable Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="TL Boost Class-H Tracking Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="TL Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="TL AMP Enable Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="TL AMP Enable Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="BH Boost Class-H Tracking Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="BH Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="BH AMP Enable Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="BH AMP Enable Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="BL Boost Class-H Tracking Enable"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="BL Boost Class-H Tracking Enable"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="BL AMP Enable Switch"]' "1"
	AIST_proc -s $MIX '/mixer/ctl[@name="BL AMP Enable Switch"]' "1"
	AIST_proc -u $MIX '/mixer/ctl[@name="RX_FIR Filter"]' "ON"
	AIST_proc -s $MIX '/mixer/ctl[@name="RX_FIR Filter"]' "ON"
	AIST_proc -u $MIX '/mixer/path[@name="headphones-hifi-filter"]/ctl[@name="RX_FIR Filter"]' "ON"
	AIST_proc -s $MIX '/mixer/path[@name="headphones-hifi-filter"]/ctl[@name="RX_FIR Filter"]' "ON"
	AIST_proc -u $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="AFE Input Channels"]' "Two"
	AIST_proc -s $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="AFE Input Channels"]' "Two"
	AIST_proc -u $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="TWS Channel Mode"]' "Two"
	AIST_proc -s $MIX '/mixer/path[@name="bt-a2dp"]/ctl[@name="TWS Channel Mode"]' "Two"
	AIST_proc -u $MIX '/mixer/ctl[@name="TWS Channel Mode"]' "Two"
	AIST_proc -s $MIX '/mixer/ctl[@name="TWS Channel Mode"]' "Two"
	done

  for OAPLI in ${APINF}; do
	APLI="$MODPATH$(echo $OAPLI | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	cp_ch $ORIGDIR$OAPLI $APLI
	sed -i 's/\t/  /g' $APLI
	AIST_proc -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER"]' "24"
	AIST_proc -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES"]' "24"
	AIST_proc -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_REVERSE"]' "24"
	AIST_proc -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_PROTECTED"]' "24"
	AIST_proc -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES_44_1"]' "24"
	AIST_proc -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_SPEAKER"]' "24"
	AIST_proc -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_HEADPHONES"]' "24"
	AIST_proc -s $APLI '/audio_platform_info/bit_width_configs/device[@name="SND_DEVICE_OUT_BT_A2DP"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_REVERSE"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_PROTECTED"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES_44_1"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_SPEAKER"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_HEADPHONES"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_intcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_BT_A2DP"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_REVERSE"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_SPEAKER_PROTECTED"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_HEADPHONES_44_1"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_SPEAKER"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_GAME_HEADPHONES"]' "24"
	AIST_proc -s $APLI '/audio_platform_info_extcodec/bit_width_configs/device[@name="SND_DEVICE_OUT_BT_A2DP"]' "24"
	sed -i 's/name="SND_DEVICE_OUT_SPEAKER" bit_width="16"/name="SND_DEVICE_OUT_SPEAKER" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_HEADPHONES" bit_width="16"/name="SND_DEVICE_OUT_HEADPHONES" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_SPEAKER_REVERSE" bit_width="16"/name="SND_DEVICE_OUT_SPEAKER_REVERSE" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_SPEAKER_PROTECTED" bit_width="16"/name="SND_DEVICE_OUT_SPEAKER_PROTECTED" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_HEADPHONES_44_1" bit_width="16"/name="SND_DEVICE_OUT_HEADPHONES_44_1" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_GAME_SPEAKER" bit_width="16"/name="SND_DEVICE_OUT_GAME_SPEAKER" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_GAME_HEADPHONES" bit_width="16"/name="SND_DEVICE_OUT_GAME_HEADPHONES" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_BT_A2DP" bit_width="16"/name="SND_DEVICE_OUT_BT_A2DP" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_SPEAKER" value="24"/name="SND_DEVICE_OUT_SPEAKER" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_HEADPHONES" value="24"/name="SND_DEVICE_OUT_HEADPHONES" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_SPEAKER_REVERSE" value="24"/name="SND_DEVICE_OUT_SPEAKER_REVERSE" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_SPEAKER_PROTECTED" value="24"/name="SND_DEVICE_OUT_SPEAKER_PROTECTED" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_HEADPHONES_44_1" value="24"/name="SND_DEVICE_OUT_HEADPHONES_44_1" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_GAME_SPEAKER" value="24"/name="SND_DEVICE_OUT_GAME_SPEAKER" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_GAME_HEADPHONES" value="24"/name="SND_DEVICE_OUT_GAME_HEADPHONES" bit_width="32"/g' $APLI
	sed -i 's/name="SND_DEVICE_OUT_BT_A2DP" value="24"/name="SND_DEVICE_OUT_BT_A2DP" bit_width="32"/g' $APLI
	AIST_proc -s $APLI '/audio_platform_info/app_types/app[@mode="default"]' 'bit_width=32'
	AIST_proc -s $APLI '/audio_platform_info/app_types/app[@mode="default"]' 'max_rate=384000'
	AIST_proc -s $APLI '/audio_platform_info_intcodec/app_types/app[@mode="default"]' 'bit_width=32'
	AIST_proc -s $APLI '/audio_platform_info_intcodec/app_types/app[@mode="default"]' 'max_rate=384000'
	AIST_proc -s $APLI '/audio_platform_info_extcodec/app_types/app[@mode="default"]' 'bit_width=32'
	AIST_proc -s $APLI '/audio_platform_info_extcodec/app_types/app[@mode="default"]' 'max_rate=384000'
	if [ ! "$(grep '<app_types>' $APLI)" ]; then
	sed -i "s/<\/audio_platform_info>/  <app_types> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"32\" id=\"69936\" max_rate=\"384000\" \/> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"32\" id=\"69940\" max_rate=\"384000\" \/> \n  <app_types> \n<\/audio_platform_info>/" $APLI
	sed -i "s/<\/audio_platform_info_intcodec>/  <app_types> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"32\" id=\"69936\" max_rate=\"384000\" \/> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"32\" id=\"69940\" max_rate=\"384000\" \/> \n  <app_types> \n<\/audio_platform_info_intcodec>/" $APLI		  
	sed -i "s/<\/audio_platform_info_extcodec>/  <app_types> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"32\" id=\"69936\" max_rate=\"384000\" \/> \n    <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"32\" id=\"69940\" max_rate=\"384000\" \/> \n  <app_types> \n<\/audio_platform_info_extcodec>/" $APLI		  
	else
	for i in 69936 69940; do
	[ "$(xmlstarlet sel -t -m "/audio_platform_info/app_types/app[@uc_type=\"PCM_PLAYBACK\"][@mode=\"default\"][@id=\"$i\"]" -c . $APLI)" ] || sed -i "/<audio_platform_info>/,/<\/audio_platform_info>/ {/<app_types>/,/<\/app_types>/ s/\(^ *\)\(<\/app_types>\)/\1  <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"32\" id=\"$i\" max_rate=\"384000\" \/> \n\1\2/}" $APLI
	[ "$(xmlstarlet sel -t -m "/audio_platform_info_intcodec/app_types/app[@uc_type=\"PCM_PLAYBACK\"][@mode=\"default\"][@id=\"$i\"]" -c . $APLI)" ] || sed -i "/<audio_platform_info_intcodec>/,/<\/audio_platform_info_intcodec>/ {/<app_types>/,/<\/app_types>/ s/\(^ *\)\(<\/app_types>\)/\1  <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"32\" id=\"$i\" max_rate=\"384000\" \/> \n\1\2/}" $APLI			
	[ "$(xmlstarlet sel -t -m "/audio_platform_info_extcodec/app_types/app[@uc_type=\"PCM_PLAYBACK\"][@mode=\"default\"][@id=\"$i\"]" -c . $APLI)" ] || sed -i "/<audio_platform_info_extcodec>/,/<\/audio_platform_info_extcodec>/ {/<app_types>/,/<\/app_types>/ s/\(^ *\)\(<\/app_types>\)/\1  <app uc_type=\"PCM_PLAYBACK\" mode=\"default\" bit_width=\"32\" id=\"$i\" max_rate=\"384000\" \/> \n\1\2/}" $APLI			
	done
	fi
	done

  for OACONF in ${ACONFS}; do
	ACONF="$MODPATH$(echo $OACONF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	cp_ch $ORIGDIR$OACONF $ACONF
	sed -i 's/\t/  /g' $ACONF
	AIST_proc -u $ACONF '/configs/property[@name="audio.deep_buffer.media"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="audio.offload.video"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.av.streaming.offload.enable"]' "false"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.offload.track.enable"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.offload.multiple.enabled"]' "false"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.voice.path.for.pcm.voip"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.use.sw.alac.decoder"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.use.sw.ape.decoder"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.use.sw.mpegh.decoder"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.flac.sw.decoder.24bit"]' "true"
	AIST_proc -u $ACONF '/configs/property[@name="vendor.audio.hw.aac.encoder"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="afe_proxy_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="aac_adts_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="alac_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="ape_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="flac_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="pcm_offload_enabled_16"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="pcm_offload_enabled_24"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="qti_flac_decoder"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="vorbis_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="wma_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="a2dp_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="anc_headset_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="audio_zoom_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="audiosphere_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="custom_stereo_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="battery_listener_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="dsm_feedback_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="ext_hw_plugin_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="ext_qdsp_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="ext_spkr_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="ext_spkr_tfa_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="hfp_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="hifi_audio_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="hwdep_cal_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="incall_music_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="keep_alive_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="kpi_optimize_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="maxx_audio_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="multi_voice_session"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="receiver_aided_stereo"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="snd_monitor_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="spkr_prot_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="usb_offload_burst_mode"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="usb_offload_enabled"]' "true"
	AIST_proc -u $ACONF '/configs/flag[@name="usb_offload_sidetone_vol_enabled"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="use_deep_buffer_as_primary_output"]' "false"
	AIST_proc -u $ACONF '/configs/flag[@name="vbat_enabled"]' "false"
	done

  for OAPCXM in ${APCXML}; do
	APCXM="$MODPATH$(echo $OAPCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i 's/speaker_drc_enabled="true"/speaker_drc_enabled="false"/g' $APCXM
	sed -i 's/flags="AUDIO_OUTPUT_FLAG_PRIMARY"/flags="AUDIO_OUTPUT_FLAG_FAST|AUDIO_OUTPUT_FLAG_PRIMARY"/g' $APCXM
	sed -i 's/flags="AUDIO_OUTPUT_FLAG_RAW"/flags="AUDIO_OUTPUT_FLAG_FAST|AUDIO_OUTPUT_FLAG_RAW"/g' $APCXM
	sed -i 's/flags="AUDIO_OUTPUT_FLAG_DIRECT|AUDIO_OUTPUT_FLAG_COMPRESS_OFFLOAD|AUDIO_OUTPUT_FLAG_NON_BLOCKING">/flags="AUDIO_OUTPUT_FLAG_DIRECT|AUDIO_OUTPUT_FLAG_NON_BLOCKING">/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_MP3"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_FLAC"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_ALAC"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_APE"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_AAC_LC"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_AAC_HE_V1"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_AAC_HE_V2"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_DTS"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_DTS_HD"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_WMA"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_WMA_PRO"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_VORBIS"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_AAC_ADTS_LC"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_AAC_ADTS_HE_V1"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_AAC_ADTS_HE_V2"/profile name="" format=""/g' $APCXM
	sed -i 's/profile name="" format="AUDIO_FORMAT_DSD"/profile name="" format=""/g' $APCXM
	done

  for OAPIOCXM in ${APIOCXML}; do
	APIOCXM="$MODPATH$(echo $OAPIOCXM | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i 's/flags AUDIO_OUTPUT_FLAG_PRIMARY/flags AUDIO_OUTPUT_FLAG_FAST|AUDIO_OUTPUT_FLAG_PRIMARY/g' $APIOCXM
	sed -i 's/flags AUDIO_OUTPUT_FLAG_RAW/flags AUDIO_OUTPUT_FLAG_FAST|AUDIO_OUTPUT_FLAG_RAW/g' $APIOCXM
	sed -i 's/formats AUDIO_FORMAT_PCM_16_BIT|AUDIO_FORMAT_PCM_24_BIT_PACKED|AUDIO_FORMAT_PCM_8_24_BIT|AUDIO_FORMAT_PCM_32_BIT/formats AUDIO_FORMAT_PCM_16_BIT||AUDIO_FORMAT_PCM_FLOAT|AUDIO_FORMAT_PCM_24_BIT_PACKED|AUDIO_FORMAT_PCM_8_24_BIT|AUDIO_FORMAT_PCM_32_BIT/g' $APIOCXM
	sed -i 's/formats AUDIO_FORMAT_PCM_24_BIT_PACKED|AUDIO_FORMAT_PCM_8_24_BIT|AUDIO_FORMAT_PCM_32_BIT/formats AUDIO_FORMAT_PCM_FLOAT|AUDIO_FORMAT_PCM_24_BIT_PACKED|AUDIO_FORMAT_PCM_8_24_BIT|AUDIO_FORMAT_PCM_32_BIT/g' $APIOCXM
	sed -i 's/formats AUDIO_FORMAT_PCM_8_24_BIT|AUDIO_FORMAT_PCM_32_BIT/formats AUDIO_FORMAT_PCM_FLOAT|AUDIO_FORMAT_PCM_8_24_BIT|AUDIO_FORMAT_PCM_32_BIT/g' $APIOCXM
	sed -i 's/formats AUDIO_FORMAT_PCM_32_BIT/formats AUDIO_FORMAT_PCM_FLOAT|AUDIO_FORMAT_PCM_32_BIT/g' $APIOCXM
	sed -i 's/flags AUDIO_OUTPUT_FLAG_DIRECT|AUDIO_OUTPUT_FLAG_COMPRESS_OFFLOAD|AUDIO_OUTPUT_FLAG_NON_BLOCKING|AUDIO_OUTPUT_FLAG_COMPRESS_PASSTHROUGH/flags AUDIO_OUTPUT_FLAG_DIRECT|AUDIO_OUTPUT_FLAG_NON_BLOCKING/g' $APIOCXM
	sed -i 's/flags AUDIO_OUTPUT_FLAG_DIRECT|AUDIO_OUTPUT_FLAG_COMPRESS_OFFLOAD|AUDIO_OUTPUT_FLAG_NON_BLOCKING/flags AUDIO_OUTPUT_FLAG_DIRECT|AUDIO_OUTPUT_FLAG_NON_BLOCKING/g' $APIOCXM
	sed -i 's/formats AUDIO_FORMAT_DTS|AUDIO_FORMAT_DTS_HD|AUDIO_FORMAT_DSD/formats /g' $APIOCXM
	sed -i 's/formats AUDIO_FORMAT_MP3|AUDIO_FORMAT_PCM_24_BIT_OFFLOAD|AUDIO_FORMAT_FLAC|AUDIO_FORMAT_ALAC|AUDIO_FORMAT_APE|AUDIO_FORMAT_VORBIS|AUDIO_FORMAT_WMA|AUDIO_FORMAT_WMA_PRO/formats /g' $APIOCXM
	sed -i 's/formats AUDIO_FORMAT_MP3|AUDIO_FORMAT_PCM_16_BIT_OFFLOAD|AUDIO_FORMAT_PCM_24_BIT_OFFLOAD|AUDIO_FORMAT_FLAC|AUDIO_FORMAT_ALAC|AUDIO_FORMAT_APE|AUDIO_FORMAT_AAC_LC|AUDIO_FORMAT_AAC_HE_V1|AUDIO_FORMAT_AAC_HE_V2|AUDIO_FORMAT_WMA|AUDIO_FORMAT_WMA_PRO|AUDIO_FORMAT_VORBIS|AUDIO_FORMAT_AAC_ADTS_LC|AUDIO_FORMAT_AAC_ADTS_HE_V1|AUDIO_FORMAT_AAC_ADTS_HE_V2/formats /g' $APIOCXM
	done

  for ODEVF in ${DEVF}; do
	AODEVF="$MODPATH$(echo $ODEVF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	sed -i 's/name="btdebug_enabled">true</name="btdebug_enabled">false</g' $AODEVF
	sed -i 's/name="support_record_param">false</name="support_record_param">true</g' $AODEVF
	sed -i 's/name="support_interview_record_param">false</name="support_interview_record_param">true</g' $AODEVF
	sed -i 's/name="support_hd_record_param">false</name="support_hd_record_param">true</g' $AODEVF
	sed -i 's/name="support_voip_record">false</name="support_voip_record">true</g' $AODEVF
	sed -i 's/name="support_dolby">false</name="support_dolby">true</g' $AODEVF
	sed -i 's/name="support_hifi">false</name="support_hifi">true</g' $AODEVF
	sed -i 's/name="support_feedback_level">false</name="support_feedback_level">true</g' $AODEVF
	sed -i 's/name="support_media_feedback">false</name="support_media_feedback">true</g' $AODEVF
	sed -i 's/name="support_camera_audio_focus">false</name="support_camera_audio_focus">true</g' $AODEVF
	sed -i 's/name="support_lhdc_offload">false</name="support_lhdc_offload">true</g' $AODEVF
	sed -i 's/name="support_a2dp_latency">false</name="support_a2dp_latency">true</g' $AODEVF
	sed -i 's/name="support_sound_assist">false</name="support_sound_assist">true</g' $AODEVF
	sed -i 's/name="support_truetone">false</name="support_truetone">true</g' $AODEVF
	sed -i 's/name="support_new_silentmode">false</name="support_new_silentmode">true</g' $AODEVF
	sed -i 's/name="support_audio_share">false</name="support_audio_share">true</g' $AODEVF
	sed -i 's/name="support_qcom_sound">false</name="support_qcom_sound">true</g' $AODEVF
	sed -i 's/name="support_24bit_record">false</name="support_24bit_record">true</g' $AODEVF
	sed -i 's/name="support_audio_loopback">false</name="support_audio_loopback">true</g' $AODEVF
	sed -i 's/name="support_phone_call_noise_suppression">true</name="support_phone_call_noise_suppression">false</g' $AODEVF
	sed -i 's/name="support_bluetooth_fast_connect">false</name="support_bluetooth_fast_connect">true</g' $AODEVF
	done

  for OBTCONF in ${BTCONF}; do
	BTCON="$MODPATH$(echo $OBTCONF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	cp_ch $ORIGDIR$OBTCONF $BTCON
	sed -i 's/\t/  /g' $BTCON
	sed -i 's/aacFrameCtlEnabled = true/aacFrameCtlEnabled = false/g' $BTCON
	sed -i 's/twspStateSupported = false/twspStateSupported = true/g' $BTCON
	sed -i 's/wiPowerSupported = false/wiPowerSupported = true/g' $BTCON
	sed -i 's/spiltA2dpSupported = false/spiltA2dpSupported = true/g' $BTCON
	done

  for OBTCONF2 in ${BTCONF2}; do
	BTCON2="$MODPATH$(echo $OBTCONF2 | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	cp_ch $ORIGDIR$OBTCONF2 $BTCON2
	sed -i 's/\t/  /g' $BTCON2
	sed -i 's/TraceConf=true/TraceConf=false/g' $BTCON2
	sed -i 's/TRC_BTM=2/TRC_BTM=0/g' $BTCON2
	sed -i 's/TRC_HCI=2/TRC_HCI=0/g' $BTCON2
	sed -i 's/TRC_L2CAP=2/TRC_L2CAP=0/g' $BTCON2
	sed -i 's/TRC_RFCOMM=2/TRC_RFCOMM=0/g' $BTCON2
	sed -i 's/TRC_OBEX=2/TRC_OBEX=0/g' $BTCON2
	sed -i 's/TRC_AVCT=2/TRC_AVCT=0/g' $BTCON2
	sed -i 's/TRC_AVDT=2/TRC_AVDT=0/g' $BTCON2
	sed -i 's/TRC_AVRC=2/TRC_AVRC=0/g' $BTCON2
	sed -i 's/TRC_AVDT_SCB=2/TRC_AVDT_SCB=0/g' $BTCON2
	sed -i 's/TRC_AVDT_CCB=2/TRC_AVDT_CCB=0/g' $BTCON2
	sed -i 's/TRC_A2D=2/TRC_A2D=0/g' $BTCON2
	sed -i 's/TRC_SDP=2/TRC_SDP=0/g' $BTCON2
	sed -i 's/TRC_SMP=2/TRC_SMP=0/g' $BTCON2
	sed -i 's/TRC_BTAPP=2/TRC_BTAPP=0/g' $BTCON2
	sed -i 's/TRC_BTIF=2/TRC_BTIF=0/g' $BTCON2
	sed -i 's/TRC_BNEP=2/TRC_BNEP=0/g' $BTCON2
	sed -i 's/TRC_PAN=2/TRC_PAN=0/g' $BTCON2
	sed -i 's/TRC_HID_HOST=2/TRC_HID_HOST=0/g' $BTCON2
	sed -i 's/TRC_HID_DEV=2/TRC_HID_DEV=0/g' $BTCON2
	sed -i 's/TRC_GATT=2/TRC_GATT=0/g' $BTCON2
	done

  for ODAXXML in ${DAXXML}; do
	DAXXM="$MODPATH$(echo $ODAXXML | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/odm|g")"
	cp_ch $ORIGDIR$ODAXXML $DAXXM
	sed -i 's/\t/  /g' $DAXXM
	sed -i 's/mi-surround-compressor-steering-enable value="false"/mi-surround-compressor-steering-enable value="true"/g' $DAXXM
	sed -i 's/mi-adaptive-virtualizer-steering-enable value="false"/mi-adaptive-virtualizer-steering-enable value="true"/g' $DAXXM
	sed -i 's/mi-virtualizer-binaural-steering-enable value="true"/mi-virtualizer-binaural-steering-enable value="false"/g' $DAXXM
	sed -i 's/bass-enhancer-enable value="false"/bass-enhancer-enable value="true"/g' $DAXXM
	sed -i 's/bass-mbdrc-enable value="true"/bass-mbdrc-enable value="false"/g' $DAXXM
	sed -i 's/bass-extraction-enable value="false"/bass-extraction-enable value="true"/g' $DAXXM
	sed -i 's/virtual-bass-process-enable value="true"/virtual-bass-process-enable value="false"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="1"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="2"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="3"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="4"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="5"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="6"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="7"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="8"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="9"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="10"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="11"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="12"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="13"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="14"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/global_setting virtual_bass_process="15"/global_setting virtual_bass_process="0"/g' $DAXXM
	sed -i 's/volume-leveler-compressor-enable value="true"/volume-leveler-compressor-enable value="false"/g' $DAXXM
	sed -i 's/regulator-sibilance-suppress-enable value="true"/regulator-sibilance-suppress-enable value="false"/g' $DAXXM
	sed -i 's/virtualizer-enable value="true"/virtualizer-enable value="false"/g' $DAXXM
	sed -i 's/graphic-equalizer-enable value="false"/graphic-equalizer-enable value="true"/g' $DAXXM
	sed -i 's/reverb-suppression-enable value="false"/reverb-suppression-enable value="true"/g' $DAXXM
	sed -i 's/surround-decoder-enable value="false"/surround-decoder-enable value="true"/g' $DAXXM
	sed -i 's/hearing-protection-enable value="true"/hearing-protection-enable value="false"/g' $DAXXM
	sed -i 's/regulator-speaker-dist-enable value="false"/regulator-speaker-dist-enable value="true"/g' $DAXXM
	sed -i 's/tuned_rate="48000"/tuned_rate="192000"/g' $DAXXM
	done
