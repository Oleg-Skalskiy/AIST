#!/system/bin/sh
MODDIR=${0%/*}
# Kill audioserver PID if it was initialized already
SERVERPID=$(pidof audioserver)
[ "$SERVERPID" ] && kill $SERVERPID

#Replace
mount -o bind $MODPATH/system/vendor/odm/etc/audio/audio_policy_configuration.xml /odm/etc/audio/audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/audio_policy_configuration.xml /odm/etc/audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/audio_io_policy.conf /odm/etc/audio_io_policy.conf
mount -o bind $MODPATH/system/vendor/odm/etc/audio_platform_info.xml /odm/etc/audio_platform_info.xml
mount -o bind $MODPATH/system/vendor/odm/etc/audio_configs.xml /odm/etc/audio_configs.xml
mount -o bind $MODPATH/system/vendor/odm/etc/audio_effects.xml /odm/etc/audio_effects.xml
mount -o bind $MODPATH/system/vendor/odm/etc/audio_effects.conf /odm/etc/audio_effects.conf
mount -o bind $MODPATH/system/vendor/odm/etc/a2dp_audio_policy_configuration.xml /odm/etc/a2dp_audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/a2dp_in_audio_policy_configuration.xml /odm/etc/a2dp_in_audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/bluetooth_qti_audio_policy_configuration.xml /odm/etc/bluetooth_qti_audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml /odm/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/hearing_aid_audio_policy_configuration.xml /odm/etc/hearing_aid_audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/r_submix_audio_policy_configuration.xml /odm/etc/r_submix_audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/usb_audio_policy_configuration.xml /odm/etc/usb_audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/vehicle_display_audio_policy_configuration.xml /odm/etc/vehicle_display_audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/virtual_audio_policy_configuration.xml /odm/etc/virtual_audio_policy_configuration.xml
mount -o bind $MODPATH/system/vendor/odm/etc/media_codecs_google_audio.xml /odm/etc/media_codecs_google_audio.xml
mount -o bind $MODPATH/system/vendor/odm/etc/media_codecs_google_c2_audio.xml /odm/etc/media_codecs_google_c2_audio.xml
mount -o bind $MODPATH/system/vendor/odm/etc/media_codecs_vendor_audio.xml /odm/etc/media_codecs_vendor_audio.xml
mount -o bind $MODPATH/system/vendor/odm/etc/media_codecs_dolby_audio.xml /odm/etc/media_codecs_dolby_audio.xml
mount -o bind $MODPATH/system/vendor/odm/etc/mixer_paths.xml /odm/etc/mixer_paths.xml
mount -o bind $MODPATH/system/vendor/odm/etc/sound_trigger_mixer_paths.xml /odm/etc/sound_trigger_mixer_paths.xml
mount -o bind $MODPATH/system/vendor/odm/etc/sound_trigger_platform_info.xml /odm/etc/sound_trigger_platform_info.xml
mount -o bind $MODPATH/system/vendor/odm/etc/audio/ /odm/etc/audio/
mount -o bind $MODPATH/system/vendor/odm/etc/dolby/ /odm/etc/dolby/
mount -o bind $MODPATH/system/vendor/odm/etc/dolby/multimedia_dolby_dax_default.xml /odm/etc/dolby/multimedia_dolby_dax_default.xml
mount -o bind $MODPATH/system/vendor/odm/etc/dolby/dax_default.xml /odm/etc/dolby/dax_default.xml
mount -o bind $MODPATH/system/vendor/odm/etc/dolby/dap_default.xml /odm/etc/dolby/dap_default.xml


mount -o bind $MODPATH/system/my_product/etc/audio/audio_policy_configuration.xml /my_product/etc/audio/audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/audio_policy_configuration.xml /my_product/etc/audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/audio_io_policy.conf /my_product/etc/audio_io_policy.conf
mount -o bind $MODPATH/system/my_product/etc/audio_platform_info.xml /my_product/etc/audio_platform_info.xml
mount -o bind $MODPATH/system/my_product/etc/audio_configs.xml /my_product/etc/audio_configs.xml
mount -o bind $MODPATH/system/my_product/etc/audio_effects.xml /my_product/etc/audio_effects.xml
mount -o bind $MODPATH/system/my_product/etc/audio_effects.conf /my_product/etc/audio_effects.conf
mount -o bind $MODPATH/system/my_product/etc/a2dp_audio_policy_configuration.xml /my_product/etc/a2dp_audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/a2dp_in_audio_policy_configuration.xml /my_product/etc/a2dp_in_audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/bluetooth_qti_audio_policy_configuration.xml /my_product/etc/bluetooth_qti_audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml /my_product/etc/bluetooth_qti_hearing_aid_audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/hearing_aid_audio_policy_configuration.xml /my_product/etc/hearing_aid_audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/r_submix_audio_policy_configuration.xml /my_product/etc/r_submix_audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/usb_audio_policy_configuration.xml /my_product/etc/usb_audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/vehicle_display_audio_policy_configuration.xml /my_product/etc/vehicle_display_audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/virtual_audio_policy_configuration.xml /my_product/etc/virtual_audio_policy_configuration.xml
mount -o bind $MODPATH/system/my_product/etc/media_codecs_google_audio.xml /my_product/etc/media_codecs_google_audio.xml
mount -o bind $MODPATH/system/my_product/etc/media_codecs_google_c2_audio.xml /my_product/etc/media_codecs_google_c2_audio.xml
mount -o bind $MODPATH/system/my_product/etc/media_codecs_vendor_audio.xml /my_product/etc/media_codecs_vendor_audio.xml
mount -o bind $MODPATH/system/my_product/etc/media_codecs_dolby_audio.xml /my_product/etc/media_codecs_dolby_audio.xml
mount -o bind $MODPATH/system/my_product/etc/mixer_paths.xml /my_product/etc/mixer_paths.xml
mount -o bind $MODPATH/system/my_product/etc/sound_trigger_mixer_paths.xml /my_product/etc/sound_trigger_mixer_paths.xml
mount -o bind $MODPATH/system/my_product/etc/sound_trigger_platform_info.xml /my_product/etc/sound_trigger_platform_info.xml
mount -o bind $MODPATH/system/my_product/etc/audio/ /my_product/etc/audio/
mount -o bind $MODPATH/system/my_product/etc/dolby/ /my_product/etc/dolby/
mount -o bind $MODPATH/system/my_product/etc/dolby/multimedia_dolby_dax_default.xml /my_product/etc/dolby/multimedia_dolby_dax_default.xml
mount -o bind $MODPATH/system/my_product/etc/dolby/dax_default.xml /my_product/etc/dolby/dax_default.xml
mount -o bind $MODPATH/system/my_product/etc/dolby/dap_default.xml /my_product/etc/dolby/dap_default.xml
#Replace
