#!/system/bin/sh
MODDIR=${0%/*}
# Kill audioserver PID if it exists already
SERVERPID=$(pidof audioserver)
[ "$SERVERPID" ] && kill $SERVERPID

killall -q audioserver
killall -q mediaserver

resetprop -p --delete persist.vendor.audio_hal.dsp_bit_width_enforce_mode
resetprop -p --delete persist.audio_hal.dsp_bit_width_enforce_mode
resetprop -p --delete vendor.audio.ultrasound.stoplatency
resetprop -p --delete vendor.audio.ultrasound.usync
