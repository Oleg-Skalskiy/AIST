# Service controller script

resetprop -p --delete persist.vendor.audio_hal.dsp_bit_width_enforce_mode
resetprop -p --delete persist.audio_hal.dsp_bit_width_enforce_mode
resetprop -p --delete vendor.audio.ultrasound.stoplatency
resetprop -p --delete vendor.audio.ultrasound.usync
