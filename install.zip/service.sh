#!/system/bin/sh
MODDIR=${0%/*}
# Kill audioserver PID if it exists already
SERVERPID=$(pidof audioserver)
[ "$SERVERPID" ] && kill $SERVERPID

resetprop --delete ro.build.selinux

if [[ "$(cat /sys/fs/selinux/enforce)" == "0" ]]; then
    chmod 640 /sys/fs/selinux/enforce
    chmod 440 /sys/fs/selinux/policy
fi
